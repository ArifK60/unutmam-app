# Unutmam — Telefonda APK üretme

Bu yöntem bilgisayar gerektirmez. GitHub Actions, APK'yı bulutta üretir.

1. GitHub'da yeni bir repository oluştur.
2. Bu paketten şu iki öğeyi repository köküne yükle:
   - `.github/workflows/build-android.yml`
   - `unutmam-project.zip`
3. GitHub'da **Actions** sekmesine gir.
4. **Unutmam Android APK** workflow'unu seç.
5. **Run workflow** düğmesine bas.
6. İşlem bitince workflow sayfasındaki **Artifacts** bölümünden `unutmam-debug-apk` öğesini indir.
7. APK'yı telefonda açıp yükle.

Not: Bu debug APK'dır. Play Store için daha sonra imzalı AAB/release build yapacağız.

Güvenlik: Supabase service-role key, OpenAI secret veya Firebase server credential yükleme. Bu ilk build için hiçbir gizli anahtar gerekmiyor.
