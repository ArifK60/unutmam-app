# V15 kurulum sırası

1. Supabase projesini aç.
2. `001_init.sql` → `002_reminder_cron.sql` → `003_v6_ai_and_delivery.sql` → `004_reminder_cron_v6.sql` → `005_v15_product_hardening.sql` → `006_production_hardening.sql` → `007_security_and_recurrence_hardening.sql` migration'larını uygula.
3. Edge Function secret'larını gir:
   - `OPENAI_API_KEY`
   - `OPENAI_MODEL` (varsayılan: `gpt-5.6-luna`)
   - `OPENAI_TRANSCRIBE_MODEL` (varsayılan: `gpt-4o-mini-transcribe`)
   - FCM değişkenleri
   - Stripe değişkenleri (kullanılacaksa)
   - Google Calendar OAuth değişkenleri (kullanılacaksa)
4. `ai-parser`, `transcribe`, `reminder-worker`, `share-invite`, `share-accept`, `account-delete` fonksiyonlarını deploy et.
5. pg_cron/pg_net ile reminder-worker'ı dakikalık tetikle.
6. `frontend/config.example.js` → `config.js`.
7. Web'i HTTPS altında yayınla.
8. Mobilde:
   - `cd mobile`
   - `npm install`
   - `npm run build`
   - `npx cap add android`
   - `npx cap add ios`
   - `npx cap sync`
9. Android için Firebase `google-services.json` ekle; iOS için APNs/Push capability yapılandır.
10. Mağaza hesapları, imzalama, gizlilik metni, ekran görüntüleri ve destek URL'lerini ekle.

Bu paket canlıya deploy edilmiş değildir; son adımlar hesaplar/anahtarlar ve gerçek cihaz testleri gerektirir.
