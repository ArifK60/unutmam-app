# Unutmam yol haritası

## V4 — Cloud Ready
- hesap oluşturma / giriş
- bulut senkronizasyonu
- PostgreSQL veri modeli
- RLS
- cihaz token modeli
- hatırlatıcı worker iskeleti

## V5 — Akıllı Hatırlatıcı
- daha güçlü Türkçe tarih/saat parsing
- doğrulama ekranı
- zaman dilimi desteği

## V6 — AI çekirdeği
- gerçek AI doğal dil ayrıştırma
- Structured Outputs ile şemalı sonuç
- kritik eksik bilgide tek soruluk netleştirme
- AI sonucu için onay ekranı
- düzenle ekranına otomatik doldurma
- hatırlatma öncesi süre alanı
- teslimat izleme tablosu
- AI anahtarını frontend'den uzak tutan Edge Function

## V6 sonrası üretim işleri
1. Web Push / FCM / APNs sağlayıcısını bağlamak
2. cihaz push subscription kaydı
3. worker + cron secrets
4. hesap silme / veri silme
5. gizlilik ve veri saklama ekranları
6. Android/iOS paketleme
7. hata izleme, rate limit ve kötüye kullanım koruması
8. paylaşım ve aile/ekip listeleri
