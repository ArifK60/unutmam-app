# Unutmam — mağaza metni

## Kısa açıklama
Aklına geleni yaz. Gerisini unutma.

## Uzun açıklama
Unutmam, hatırlatıcı oluşturmayı kolaylaştırır. Normal bir cümle yaz; uygulama tarih, saat, tekrar, tür ve öncelik gibi alanları anlamaya çalışır.

Örnekler:
- "Yarın dişçiye git."
- "Her ayın 5'inde internet faturasını öde."
- "20 Ekim saat 10'da arabayı servise götür."
- "Annemin doğum günü için 2 hafta önce hediye bak."

AI özelliği açık olduğunda doğal dil çözümleme sunucu tarafında yapılır. Kritik bir bilgi eksikse uygulama bunu netleştirebilir.
