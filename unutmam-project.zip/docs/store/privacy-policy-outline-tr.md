# Gizlilik Politikası Taslağı

Bu taslak hukuki danışmanlık değildir. Mağaza yayını öncesinde gerçek şirket bilgileri, veri sorumlusu kimliği, saklama süreleri, başvuru kanalları ve kullanılan üçüncü taraf hizmetler doğrulanarak tamamlanmalıdır.

## Toplanan veriler
- Hesap: e-posta, profil bilgileri
- Hatırlatıcılar: başlık, tarih/saat, tekrar, not
- Cihaz: push tokenı ve uygulama sürümü (bildirim açık ise)
- AI: kullanıcı açıkça AI özelliğini kullandığında gönderilen hatırlatıcı cümlesi
- Ödeme: ödeme sağlayıcısının gerekli müşteri/abonelik kimliği

## Kullanım
Hatırlatıcıları sunmak, senkronizasyon yapmak, bildirim göndermek, AI doğal dil çözümlemek ve aboneliği yönetmek.

## Kontrol
Kullanıcı hesabını ve uygulama verilerini silme talebinde bulunabilir. AI özelliği ayarlardan kapatılabilir.

## Güvenlik
Gizli anahtarlar yalnızca sunucu/Edge Function ortamında tutulmalıdır; uygulama içine service-role veya ödeme/AI secret'ı gömülmez.
