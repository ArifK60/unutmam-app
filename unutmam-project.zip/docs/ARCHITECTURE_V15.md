# Unutmam V15 mimarisi

## Katmanlar

**Web/PWA**
- V6 mobile-first arayüz
- yerel fallback parser
- AI confirmation
- arama/filtre

**Native**
- Capacitor 8
- Push Notifications
- Local Notifications
- Device Calendar
- Share

**Backend**
- Supabase Auth + Postgres + RLS
- Edge Functions
- cron/reminder worker
- FCM HTTP v1
- OpenAI Responses API
- OpenAI speech-to-text
- Stripe adapter
- Google Calendar OAuth adapter

## Veri güvenliği

Tarayıcı/mobil uygulama yalnızca Supabase publishable key kullanır. Supabase secret/service-role, OpenAI API key, FCM service account ve Stripe secret yalnızca sunucu tarafında tutulmalıdır.

## Bildirim

1. cihaz tokenını kaydeder
2. görev için `scheduled_for` hesaplanır
3. worker idempotent `reminder_deliveries` satırı oluşturur
4. FCM ile push gönderir
5. gönderim sonucu kaydedilir

FCM HTTP v1 tek cihaz tokenına bildirim göndermeyi destekler; sunucu tarafı OAuth/service-account kimlik doğrulaması kullanır. 
