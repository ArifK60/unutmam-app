# Unutmam — Release Gate V15.2

Bu sürümde kod tarafında production-hardening uygulanmıştır. Mağazaya çıkmadan önce aşağıdaki kapıların tamamı PASS olmalıdır.

## A — Gerçek servisler
- [ ] Supabase production project
- [ ] 001/003/005/006 migrations applied
- [ ] Edge Functions deployed
- [ ] OpenAI key + model configured (`gpt-5.6-luna` default; transcription model separately configured)
- [ ] Reminder cron/worker active
- [ ] Firebase/FCM credentials configured
- [ ] APNs/iOS push configuration completed
- [ ] Deep-link domain / `unutmam://` handling verified

## B — Gerçek cihazlar
- [ ] Android physical device
- [ ] iPhone physical device
- [ ] app open/background/terminated notification
- [ ] reboot test
- [ ] permission denied/granted test
- [ ] offline create → online sync
- [ ] duplicate notification test
- [ ] deep-link from notification

## C — Savaş testi
- [ ] 400 Turkish stress corpus executed against deployed AI parser
- [ ] ambiguous phrases must clarify, not invent
- [ ] timezone/DST tests
- [ ] Google Calendar create/update/delete
- [ ] device calendar create/update/delete
- [ ] family invite/leave/remove/unauthorized access
- [ ] password reset
- [ ] account deletion and data cascade
- [ ] export/import
- [ ] 10,000-record performance test
- [ ] offline conflict resolution

## D — Store
- [ ] Android AAB release build
- [ ] signing / Play Console
- [ ] iOS archive
- [ ] Bundle ID / signing / APNs
- [ ] TestFlight
- [ ] privacy/data safety declarations
- [ ] store screenshots/listing/support URL

## Hard release rule
**Herhangi bir kritik kutu FAIL ise yayın yok.** Özellikle bildirim, veri kaybı, hesap silme, yetkisiz erişim ve offline senkronizasyon testleri geçmeden mağaza yüklemesi yapılmaz.
