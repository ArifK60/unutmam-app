# Unutmam — Android İlk Çalıştırma

## Gerekenler
- Windows 10/11
- Node.js 20+ LTS
- Android Studio
- Android SDK + platform tools
- USB debugging açık Android telefon (fiziksel test için)

## 1. Paketi çıkar
ZIP'i örneğin `C:\Unutmam` klasörüne çıkar.

## 2. Tek tık kurulum
`v155/scripts/setup-android.bat` dosyasını çalıştır.

Script:
1. npm bağımlılıklarını kurar
2. Capacitor Android projesini oluşturur
3. Vite production build alır
4. Capacitor sync yapar

## 3. Android Studio
`v155/mobile` klasöründe:

```powershell
npx cap open android
```

Android Studio'da Gradle sync tamamlandıktan sonra:
`Build > Build APK(s)`

## 4. Gerçek telefon
Telefonda Geliştirici Seçenekleri + USB hata ayıklama açılır. Android Studio cihazı gördüğünde Run ile uygulama yüklenir.

## 5. İlk smoke test
- Uygulama açılıyor mu?
- “Yarın 09:00'da toplantım var” kaydoluyor mu?
- Uygulama kapatılıp tekrar açılınca kayıt duruyor mu?
- Uçak modunda yeni kayıt oluşturuluyor mu?
- İnternet açılınca kayıt senkronize oluyor mu?

Push bildirim testi için Firebase/FCM bağlantısı ayrıca yapılmalıdır.

## Güvenlik
OpenAI secret, Supabase service-role/secret key veya Firebase server credentials mobil uygulamaya konulmaz. Bunlar sunucu/Edge Function tarafında tutulur.
