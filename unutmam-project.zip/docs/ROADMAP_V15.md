# V7 → V15 durum

| Sürüm | Kapsam | Durum |
|---|---|---|
| V7 | Gerçek push mimarisi + FCM worker | Kod hazır, provider secrets ve cihaz kayıtları bağlanmalı |
| V8 | Android/iOS Capacitor kabuğu | Proje hazır, native build için platform toolchain gerekli |
| V9 | AI 2.0 | GPT-6 Luna + structured parser + netleştirme |
| V10 | Sesli komut | Web Speech fallback + native/server transcription |
| V11 | Arama/filtre/gelişmiş tekrarlar | Arama + filtre + recurrence altyapısı |
| V12 | Aile/paylaşım | list/member/share invite altyapısı |
| V13 | Takvim | native device calendar + ICS + Google OAuth scaffold |
| V14 | Güvenlik/perf/ölçek | RLS, search index, usage, audit, deletion request |
| V15 | Mağaza/monetizasyon | pricing, Stripe scaffold, store/privacy docs |

## Gerçekten tamamlanmadan “tamam” sayılmaması gerekenler
- Android gerçek cihaz push testi
- iOS gerçek cihaz push testi
- FCM credentials doğrulaması
- Google/Apple calendar hesabı ile end-to-end test
- Stripe webhook end-to-end test
- hesap silme ve veri export deneyi
- Play Store/App Store review süreci
