# Unutmam — Production Runbook

## 0. Kural
Bu dosya gerçek production sırlarını içermez. Secret'lar yalnızca Supabase/CI secret store'da tutulur.

## 1. Migration sırası
Sırasıyla çalıştır:
1. 001_init.sql
2. 002_reminder_cron.sql
3. 003_v6_ai_and_delivery.sql
4. 004_reminder_cron_v6.sql
5. 005_v15_product_hardening.sql
6. 006_production_hardening.sql
7. 007_security_and_recurrence_hardening.sql

Migration'ları production'da elle parça parça çalıştırmak yerine Supabase CLI migration history ile yönet.

## 2. Edge Functions
Production'a deploy edilecekler:
- ai-parser
- reminder-worker
- transcribe
- share-invite
- share-accept
- account-delete
- calendar-google-start
- calendar-google-callback

Stripe fonksiyonları ödeme açılacaksa ayrıca deploy/test edilir; ödeme akışı doğrulanmadan Pro satın alma production'da açılmaz.

## 3. Secrets
Zorunlu:
- SUPABASE_URL
- SUPABASE_ANON_KEY / publishable key
- SUPABASE_SERVICE_ROLE_KEY (server-side only)
- OPENAI_API_KEY
- OPENAI_MODEL
- OPENAI_TRANSCRIBE_MODEL
- FCM_PROJECT_ID
- FCM_CLIENT_EMAIL
- FCM_PRIVATE_KEY

Google Calendar açılacaksa:
- GOOGLE_CLIENT_ID
- GOOGLE_CLIENT_SECRET
- GOOGLE_REDIRECT_URI

## 4. Cron
`reminder-worker` dakikada bir tetiklenmeli. Worker idempotency/lease ile duplicate gönderimi engeller. Cron çağrısında function secret yalnızca server-side tutulur.

## 5. Android
- Firebase projesi
- Android app / package id
- google-services.json
- POST_NOTIFICATIONS izni
- FCM token registration
- release keystore
- AAB üretimi
- fiziksel cihaz testi

## 6. iOS
- Apple Developer Team
- Bundle ID
- Push Notifications capability
- APNs key/certificate
- provisioning/signing
- fiziksel iPhone testi
- TestFlight

## 7. Release smoke test
Aşağıdaki 12 senaryo production öncesi PASS olmalı:
1. Online reminder create
2. Offline reminder create
3. Offline delete
4. Reconnect sync
5. App closed push
6. Device restarted push
7. Notification permission denied
8. Duplicate delivery test
9. Account deletion
10. Share invite/accept/remove
11. Calendar create/update/delete
12. New phone login + data restore

## 8. 10K performance
Yalnızca staging DB'de `tests/perf/seed-10k.sql` kullan. `tests/perf/queries.sql` sorgularını EXPLAIN ANALYZE ile ölç. Production verisine seed çalıştırma.

## 9. Go/No-Go
Gerçek cihaz, push, sync, security ve store build testleri PASS değilse release NO-GO.
