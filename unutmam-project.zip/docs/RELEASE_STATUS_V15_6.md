# Unutmam 15.6 — Release Status

## Completed in this package
- Supabase migrations 001→007 present and ordered.
- Production preflight passes.
- Static release gates pass.
- 400 Turkish stress corpus present.
- Reminder delivery claim/lease/retry hardening present.
- Offline queue and soft-delete foundation present.
- Sharing/RLS hardening present.
- Google Calendar OAuth callback fixed to a single HTTP handler.
- Google Calendar OAuth state is signed and expires after 10 minutes.
- Google Calendar refresh tokens are encrypted with AES-256-GCM before storage.
- Mobile app version strings aligned to 15.6.0.

## Still requires external credentials/devices
- A real Supabase production project and deployment.
- OpenAI API key configured in Supabase Edge Functions.
- Firebase/FCM project and Android application credentials.
- Apple Developer account, Bundle ID, APNs/signing and TestFlight.
- Physical Android and iPhone push tests with the app closed.
- Real Google OAuth consent/client configuration.
- Store signing and final Play Store/App Store submissions.

## Go/No-Go rule
Do not mark the app production-ready until the external items above have a recorded PASS on real infrastructure/devices.
