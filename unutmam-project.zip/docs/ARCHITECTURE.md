# Unutmam V4 mimarisi

Kullanıcı → PWA → Supabase Auth → PostgreSQL/RLS
                         ↘ device_tokens

PostgreSQL `due_at` → Cron → Edge Function → Push sağlayıcısı → cihaz

Yerel-first davranış:
- Ağ yoksa kayıtlar cihazda tutulur.
- Bulut modu açıldığında giriş yapan kullanıcının kayıtları Supabase'den çekilir.
- Kullanıcı verileri RLS ile `user_id` üzerinden izole edilir.

Üretim öncesi sertleştirme:
- offline queue + conflict resolution
- idempotent notification delivery
- rate limiting
- audit/event logs
- hesap/veri silme ve dışa aktarma
- paylaşılan kayıtlar için ayrı yetkilendirme kuralları
