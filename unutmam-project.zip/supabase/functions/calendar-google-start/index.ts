import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
const CLIENT_ID = Deno.env.get("GOOGLE_CLIENT_ID") || "";
const REDIRECT_URI = Deno.env.get("GOOGLE_REDIRECT_URI") || "";
const STATE_SECRET = Deno.env.get("GOOGLE_OAUTH_STATE_SECRET") || "";

const b64url = (bytes: Uint8Array) => btoa(String.fromCharCode(...bytes)).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
async function hmac(message:string){
  const key=await crypto.subtle.importKey("raw",new TextEncoder().encode(STATE_SECRET),{name:"HMAC",hash:"SHA-256"},false,["sign"]);
  return b64url(new Uint8Array(await crypto.subtle.sign("HMAC",key,new TextEncoder().encode(message))));
}

Deno.serve(async (req) => {
  try {
    if (req.method !== "GET") return Response.json({error:"Method not allowed"},{status:405});
    if (!CLIENT_ID || !REDIRECT_URI || !STATE_SECRET) return Response.json({error:"Google calendar OAuth is not configured"},{status:501});
    const auth=req.headers.get("Authorization");
    if(!auth) return Response.json({error:"Unauthorized"},{status:401});
    const client=createClient(SUPABASE_URL,SUPABASE_ANON_KEY,{global:{headers:{Authorization:auth}}});
    const {data,error}=await client.auth.getUser();
    if(error||!data.user) return Response.json({error:"Unauthorized"},{status:401});

    const payload=`${data.user.id}.${Math.floor(Date.now()/1000)}`;
    const state=`${payload}.${await hmac(payload)}`;
    const url=new URL("https://accounts.google.com/o/oauth2/v2/auth");
    url.searchParams.set("client_id",CLIENT_ID);
    url.searchParams.set("redirect_uri",REDIRECT_URI);
    url.searchParams.set("response_type","code");
    url.searchParams.set("scope","https://www.googleapis.com/auth/calendar.events.readonly https://www.googleapis.com/auth/calendar.events");
    url.searchParams.set("access_type","offline");
    url.searchParams.set("prompt","consent");
    url.searchParams.set("state",state);
    return Response.redirect(url.toString(),302);
  } catch(e) {
    return Response.json({error:e instanceof Error?e.message:"OAuth start failed"},{status:500});
  }
});
