import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const url = Deno.env.get("SUPABASE_URL")!;
const key = Deno.env.get("SUPABASE_SECRET_KEY") || Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const db = createClient(url, key);

const CRON_SECRET = Deno.env.get("UNUTMAM_CRON_SECRET") || "";
const WINDOW_MS = 60_000;
const FCM_PROJECT_ID = Deno.env.get("FCM_PROJECT_ID") || "";
const FCM_CLIENT_EMAIL = Deno.env.get("FCM_CLIENT_EMAIL") || "";
const FCM_PRIVATE_KEY = (Deno.env.get("FCM_PRIVATE_KEY") || "").replace(/\\n/g, "\n");

function base64Url(input: ArrayBuffer | Uint8Array) {
  const bytes = input instanceof Uint8Array ? input : new Uint8Array(input);
  let s = "";
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
}

async function signJwt(header: Record<string,unknown>, claims: Record<string,unknown>) {
  const enc = new TextEncoder();
  const data = `${base64Url(enc.encode(JSON.stringify(header)))}.${base64Url(enc.encode(JSON.stringify(claims)))}`;
  const pem = FCM_PRIVATE_KEY.replace(/-----BEGIN PRIVATE KEY-----|-----END PRIVATE KEY-----|\s/g,"");
  const binary = Uint8Array.from(atob(pem), c => c.charCodeAt(0));
  const key = await crypto.subtle.importKey("pkcs8", binary, {name:"RSASSA-PKCS1-v1_5",hash:"SHA-256"}, false, ["sign"]);
  const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, enc.encode(data));
  return `${data}.${base64Url(sig)}`;
}

async function fcmAccessToken() {
  if (!FCM_PROJECT_ID || !FCM_CLIENT_EMAIL || !FCM_PRIVATE_KEY) throw new Error("FCM secrets missing");
  const now = Math.floor(Date.now()/1000);
  const jwt = await signJwt(
    {alg:"RS256",typ:"JWT"},
    {iss:FCM_CLIENT_EMAIL,scope:"https://www.googleapis.com/auth/firebase.messaging",aud:"https://oauth2.googleapis.com/token",iat:now,exp:now+3600}
  );
  const r = await fetch("https://oauth2.googleapis.com/token",{
    method:"POST",
    headers:{"Content-Type":"application/x-www-form-urlencoded"},
    body:new URLSearchParams({grant_type:"urn:ietf:params:oauth:grant-type:jwt-bearer",assertion:jwt})
  });
  if(!r.ok) throw new Error(`OAuth token error: ${await r.text()}`);
  const d=await r.json(); return d.access_token as string;
}

async function sendPush(token: string, payload: {title:string;body:string;item_id:string}) {
  const access = await fcmAccessToken();
  const r = await fetch(`https://fcm.googleapis.com/v1/projects/${FCM_PROJECT_ID}/messages:send`,{
    method:"POST",
    headers:{"Authorization":`Bearer ${access}`,"Content-Type":"application/json"},
    body:JSON.stringify({
      message:{
        token,
        notification:{title:payload.title,body:payload.body},
        data:{item_id:payload.item_id,deep_link:`unutmam://item/${payload.item_id}`},
        android:{priority:"high",notification:{channel_id:"unutmam_reminders"}},
      }
    })
  });
  const d=await r.json().catch(()=>({}));
  if(!r.ok) return {ok:false,error:d?.error?.message||"FCM send failed"};
  return {ok:true,provider_message_id:d?.name||null};
}

function reminderAt(dueAt:string, offset:number){ return new Date(new Date(dueAt).getTime()-offset*60000); }

Deno.serve(async(req)=>{
  try {
    if (!CRON_SECRET || req.headers.get("x-unutmam-cron-secret") !== CRON_SECRET) {
      return Response.json({ok:false,error:"Unauthorized"},{status:401});
    }
    const now=new Date();
    const horizon=new Date(now.getTime()+WINDOW_MS);
    const scanUntil=new Date(now.getTime()+7*24*60*60*1000+WINDOW_MS);
    const {data: items,error} = await db.from("items")
      .select("id,user_id,title,due_at,reminder_offset_minutes")
      .eq("done",false).is("archived_at",null).not("due_at","is",null)
      .gte("due_at",new Date(now.getTime()-7*24*60*60*1000).toISOString())
      .lte("due_at",scanUntil.toISOString());
    if(error) throw error;

    let created=0,delivered=0,failed=0,skipped=0;
    for(const item of items||[]){
      const scheduled=reminderAt(item.due_at,Number(item.reminder_offset_minutes)||0);
      if(scheduled<now || scheduled>=horizon) continue;

      const base={user_id:item.user_id,item_id:item.id,scheduled_for:scheduled.toISOString(),channel:"push"};
      const {error: insertError}=await db.from("reminder_deliveries")
        .upsert({...base,status:"pending",next_attempt_at:new Date().toISOString()},{onConflict:"item_id,scheduled_for,channel",ignoreDuplicates:true});
      if(insertError){ failed++; continue; }
      created++;

      const {data: delivery,error: fetchError}=await db.from("reminder_deliveries")
        .select("id,status,attempt_count")
        .eq("item_id",item.id).eq("scheduled_for",scheduled.toISOString()).eq("channel","push")
        .maybeSingle();
      if(fetchError||!delivery){ failed++; continue; }
      if(delivery.status==="sent"){ skipped++; continue; }
      if((delivery.attempt_count||0)>=5){ skipped++; continue; }

      const lockToken=crypto.randomUUID();
      const {data: claimed,error: claimError}=await db.rpc("claim_reminder_delivery",{p_delivery_id:delivery.id,p_lock_token:lockToken});
      if(claimError||!claimed){ skipped++; continue; }

      const {data: tokens}=await db.from("device_tokens")
        .select("endpoint,platform,enabled")
        .eq("user_id",item.user_id).eq("enabled",true);
      let sent=false;
      let lastError="No supported push token";
      for(const token of tokens||[]){
        if(token.endpoint && token.platform==="android"){
          const result=await sendPush(token.endpoint,{title:"Unutmam",body:item.title,item_id:item.id});
          if(result.ok){
            sent=true; delivered++;
            await db.from("reminder_deliveries").update({status:"sent",sent_at:new Date().toISOString(),provider_message_id:result.provider_message_id,locked_at:null,lock_token:null}).eq("id",delivery.id).eq("lock_token",lockToken);
            break;
          }
          lastError=result.error||lastError;
          await db.from("audit_events").insert({user_id:item.user_id,event_type:"push_delivery_failed",entity_id:item.id,metadata:{platform:token.platform,error:result.error}});
        }
      }
      if(!sent){
        failed++;
        const attempts=(delivery.attempt_count||0)+1;
        const retry=Math.min(15*60_000,Math.max(30_000,2**Math.max(0,attempts-1)*10_000));
        await db.from("reminder_deliveries").update({status:attempts>=5?"failed":"pending",error:lastError,next_attempt_at:new Date(Date.now()+retry).toISOString(),locked_at:null,lock_token:null}).eq("id",delivery.id).eq("lock_token",lockToken);
      }
    }
    return Response.json({ok:true,created,delivered,failed,skipped});
  } catch(e){
    return Response.json({ok:false,error:e instanceof Error?e.message:"worker_failed"},{status:500});
  }
});
