import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const url=Deno.env.get("SUPABASE_URL")!; const anon=Deno.env.get("SUPABASE_ANON_KEY")!; const secret=Deno.env.get("SUPABASE_SECRET_KEY")||Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
Deno.serve(async(req)=>{
  try{
    if(req.method!=="POST")return Response.json({error:"Method not allowed"},{status:405});
    const auth=req.headers.get("Authorization"); if(!auth)return Response.json({error:"Unauthorized"},{status:401});
    const caller=createClient(url,anon,{global:{headers:{Authorization:auth}}});
    const {data:u}=await caller.auth.getUser(); if(!u.user)return Response.json({error:"Unauthorized"},{status:401});
    const {invite_code}=await req.json(); const code=String(invite_code||"").trim().toUpperCase();
    const db=createClient(url,secret);
    const {data:share}=await db.from("shares").select("id,list_id,expires_at").eq("invite_code",code).maybeSingle();
    if(!share)return Response.json({error:"Invite not found"},{status:404});
    if(share.expires_at && new Date(share.expires_at)<new Date())return Response.json({error:"Invite expired"},{status:410});
    const {data:list}=await db.from("lists").select("id,owner_id").eq("id",share.list_id).maybeSingle();
    if(!list)return Response.json({error:"List not found"},{status:404});
    if(list.owner_id===u.user.id)return Response.json({error:"Owner cannot accept own invite"},{status:409});
    await db.from("list_members").upsert({list_id:share.list_id,user_id:u.user.id,role:"member"});
    await db.from("shares").update({accepted_by:u.user.id,accepted_at:new Date().toISOString()}).eq("id",share.id);
    return Response.json({ok:true,list_id:share.list_id});
  }catch(e){return Response.json({error:e instanceof Error?e.message:"unknown"},{status:500})}
});
