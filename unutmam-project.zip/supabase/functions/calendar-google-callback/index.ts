import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL=Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY=Deno.env.get("SUPABASE_SECRET_KEY")||Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")||"";
const CLIENT_ID=Deno.env.get("GOOGLE_CLIENT_ID")||"";
const CLIENT_SECRET=Deno.env.get("GOOGLE_CLIENT_SECRET")||"";
const REDIRECT_URI=Deno.env.get("GOOGLE_REDIRECT_URI")||"";
const STATE_SECRET=Deno.env.get("GOOGLE_OAUTH_STATE_SECRET")||"";
const ENCRYPTION_KEY=Deno.env.get("CALENDAR_TOKEN_ENCRYPTION_KEY")||"";

const b64url=(bytes:Uint8Array)=>btoa(String.fromCharCode(...bytes)).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
const fromB64=(s:string)=>Uint8Array.from(atob(s.replace(/-/g,"+").replace(/_/g,"/")+"==="),c=>c.charCodeAt(0));
async function hmac(message:string){const key=await crypto.subtle.importKey("raw",new TextEncoder().encode(STATE_SECRET),{name:"HMAC",hash:"SHA-256"},false,["sign"]);return b64url(new Uint8Array(await crypto.subtle.sign("HMAC",key,new TextEncoder().encode(message))));}
function safeEqual(a:string,b:string){if(a.length!==b.length)return false;let x=0;for(let i=0;i<a.length;i++)x|=a.charCodeAt(i)^b.charCodeAt(i);return x===0;}
async function encrypt(value:string){
  const raw=fromB64(ENCRYPTION_KEY);
  if(raw.length!==32)throw new Error("CALENDAR_TOKEN_ENCRYPTION_KEY must be 32-byte base64");
  const key=await crypto.subtle.importKey("raw",raw,{name:"AES-GCM"},false,["encrypt"]);
  const iv=crypto.getRandomValues(new Uint8Array(12));
  const ct=new Uint8Array(await crypto.subtle.encrypt({name:"AES-GCM",iv},key,new TextEncoder().encode(value)));
  return `${b64url(iv)}.${b64url(ct)}`;
}

Deno.serve(async(req)=>{
 try{
  if(req.method!=="GET")return Response.json({error:"Method not allowed"},{status:405});
  if(!CLIENT_ID||!CLIENT_SECRET||!REDIRECT_URI||!STATE_SECRET||!SERVICE_KEY||!ENCRYPTION_KEY)return Response.json({error:"Google calendar OAuth is not fully configured"},{status:501});
  const u=new URL(req.url),code=u.searchParams.get("code"),state=u.searchParams.get("state")||"",oauthError=u.searchParams.get("error");
  if(oauthError)return Response.json({error:"Google OAuth cancelled",detail:oauthError},{status:400});
  if(!code||!state)return Response.json({error:"Missing code or state"},{status:400});
  const parts=state.split(".");
  if(parts.length!==3)return Response.json({error:"Invalid OAuth state"},{status:400});
  const userId=parts[0],issued=Number(parts[1]),sig=parts[2];
  if(!userId||!Number.isFinite(issued)||Math.abs(Math.floor(Date.now()/1000)-issued)>600)return Response.json({error:"Expired OAuth state"},{status:400});
  const expected=await hmac(`${userId}.${issued}`);
  if(!safeEqual(sig,expected))return Response.json({error:"Invalid OAuth state"},{status:400});

  const tokenResp=await fetch("https://oauth2.googleapis.com/token",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams({code,client_id:CLIENT_ID,client_secret:CLIENT_SECRET,redirect_uri:REDIRECT_URI,grant_type:"authorization_code"})});
  const token=await tokenResp.json();
  if(!tokenResp.ok||!token.access_token)return Response.json({error:"Google token exchange failed",detail:token?.error_description||token?.error},{status:502});

  let calendarId="primary",accountLabel="Google Calendar";
  const listResp=await fetch("https://www.googleapis.com/calendar/v3/users/me/calendarList?minAccessRole=writer",{headers:{Authorization:`Bearer ${token.access_token}`}});
  if(listResp.ok){const list=await listResp.json();const primary=(list.items||[]).find((x:any)=>x.primary);if(primary){calendarId=primary.id;accountLabel=primary.summary||accountLabel;}}
  const refresh=String(token.refresh_token||"");
  if(!refresh)return Response.json({error:"Google did not return a refresh token; reconnect with consent"},{status:409});
  const encrypted=await encrypt(refresh);
  const admin=createClient(SUPABASE_URL,SERVICE_KEY);
  const {error}=await admin.from("calendar_connections").upsert({user_id:userId,provider:"google",account_label:accountLabel,encrypted_refresh_token:encrypted,calendar_id:calendarId,updated_at:new Date().toISOString()},{onConflict:"user_id,provider,account_label"});
  if(error)throw error;
  return Response.json({ok:true,provider:"google",calendar_id:calendarId});
 }catch(e){return Response.json({error:e instanceof Error?e.message:"OAuth callback failed"},{status:500});}
});
