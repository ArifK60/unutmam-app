import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const url=Deno.env.get("SUPABASE_URL")!; const anon=Deno.env.get("SUPABASE_ANON_KEY")!; const secret=Deno.env.get("SUPABASE_SECRET_KEY")||Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
Deno.serve(async(req)=>{
  try{
    if(req.method!=="POST")return Response.json({error:"Method not allowed"},{status:405});
    const auth=req.headers.get("Authorization"); if(!auth)return Response.json({error:"Unauthorized"},{status:401});
    const caller=createClient(url,anon,{global:{headers:{Authorization:auth}}});
    const {data:u}=await caller.auth.getUser(); if(!u.user)return Response.json({error:"Unauthorized"},{status:401});
    const body=await req.json(); const listId=String(body.list_id||"");
    const db=createClient(url,secret);
    const {data:list}=await db.from("lists").select("id,name,owner_id").eq("id",listId).eq("owner_id",u.user.id).maybeSingle();
    if(!list)return Response.json({error:"List not found"},{status:404});
    const code=crypto.randomUUID().replace(/-/g,"").slice(0,12).toUpperCase();
    const {data:share,error}=await db.from("shares").insert({list_id:listId,owner_id:u.user.id,invite_code:code,expires_at:new Date(Date.now()+7*86400000).toISOString()}).select("invite_code").single();
    if(error)throw error;
    return Response.json({invite_code:share.invite_code,expires_at:new Date(Date.now()+7*86400000).toISOString()});
  }catch(e){return Response.json({error:e instanceof Error?e.message:"unknown"},{status:500})}
});
