import Stripe from "npm:stripe@18.5.0";
const secret=Deno.env.get("STRIPE_SECRET_KEY")||"";
const webhookSecret=Deno.env.get("STRIPE_WEBHOOK_SECRET")||"";
Deno.serve(async(req)=>{
  const sig=req.headers.get("stripe-signature")||""; const body=await req.text();
  if(!secret||!webhookSecret)return Response.json({error:"Stripe not configured"},{status:501});
  const stripe=new Stripe(secret,{apiVersion:"2025-04-30.basil"});
  try{
    const event=stripe.webhooks.constructEvent(body,sig,webhookSecret);
    // TODO: upsert subscriptions table from checkout/subscription events.
    return Response.json({received:true,type:event.type});
  }catch(e){return Response.json({error:"Invalid signature"},{status:400})}
});
