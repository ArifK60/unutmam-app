import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const url=Deno.env.get("SUPABASE_URL")!;
const secret=Deno.env.get("SUPABASE_SECRET_KEY")||Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const anon=Deno.env.get("SUPABASE_ANON_KEY")!;

Deno.serve(async(req)=>{
 try{
  if(req.method!=="POST")return Response.json({error:"Method not allowed"},{status:405});
  const auth=req.headers.get("Authorization"); if(!auth)return Response.json({error:"Unauthorized"},{status:401});
  const body=await req.json().catch(()=>({}));
  if(body?.confirm!==true)return Response.json({error:"Explicit confirmation required"},{status:400});
  const client=createClient(url,anon,{global:{headers:{Authorization:auth}}});
  const {data:u,error:userError}=await client.auth.getUser();
  if(userError||!u.user)return Response.json({error:"Unauthorized"},{status:401});
  const admin=createClient(url,secret);
  const {error:requestError}=await admin.from("deletion_requests").upsert({user_id:u.user.id,status:"processing",requested_at:new Date().toISOString()});
  if(requestError)throw requestError;
  const {error:deleteError}=await admin.auth.admin.deleteUser(u.user.id);
  if(deleteError){await admin.from("deletion_requests").update({status:"failed"}).eq("user_id",u.user.id);throw deleteError;}
  return Response.json({ok:true,status:"deleted"});
 }catch(e){return Response.json({error:e instanceof Error?e.message:"unknown"},{status:500})}
});
