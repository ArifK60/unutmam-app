import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL=Deno.env.get("SUPABASE_URL")!;
const SUPABASE_ANON_KEY=Deno.env.get("SUPABASE_ANON_KEY")!;
const OPENAI_API_KEY=Deno.env.get("OPENAI_API_KEY")!;
const MODEL=Deno.env.get("OPENAI_TRANSCRIBE_MODEL")||"gpt-4o-mini-transcribe";

Deno.serve(async(req)=>{
  try{
    if(req.method!=="POST") return Response.json({error:"Method not allowed"},{status:405});
    const auth=req.headers.get("Authorization"); if(!auth)return Response.json({error:"Unauthorized"},{status:401});
    const supabase=createClient(SUPABASE_URL,SUPABASE_ANON_KEY,{global:{headers:{Authorization:auth}}});
    const {data,error}=await supabase.auth.getUser(); if(error||!data.user)return Response.json({error:"Unauthorized"},{status:401});
    const form=await req.formData();
    const audio=form.get("audio"); if(!(audio instanceof File))return Response.json({error:"audio is required"},{status:400});
    if(audio.size>12*1024*1024)return Response.json({error:"audio too large"},{status:400});

    const fd=new FormData();
    fd.append("file",audio,audio.name||"voice.webm");
    fd.append("model",MODEL);
    fd.append("language","tr");
    const r=await fetch("https://api.openai.com/v1/audio/transcriptions",{
      method:"POST",headers:{Authorization:`Bearer ${OPENAI_API_KEY}`},body:fd
    });
    if(!r.ok)return Response.json({error:"Transcription failed",detail:(await r.text()).slice(0,500)},{status:502});
    const out=await r.json();
    await supabase.from("audit_events").insert({user_id:data.user.id,event_type:"voice_transcription",metadata:{chars:String(out.text||"").length}});
    return Response.json({text:out.text||""});
  }catch(e){return Response.json({error:e instanceof Error?e.message:"unknown"},{status:500})}
});
