import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const URL=Deno.env.get("SUPABASE_URL")!; const ANON=Deno.env.get("SUPABASE_ANON_KEY")!;
Deno.serve(async(req)=>{
  if(req.method!=="POST")return Response.json({error:"Method not allowed"},{status:405});
  const auth=req.headers.get("Authorization"); if(!auth)return Response.json({error:"Unauthorized"},{status:401});
  const sb=createClient(URL,ANON,{global:{headers:{Authorization:auth}}}); const {data:u}=await sb.auth.getUser();
  if(!u.user)return Response.json({error:"Unauthorized"},{status:401});
  // TODO: integrate Stripe Checkout server-side and create a subscription.
  return Response.json({error:"Stripe not configured yet",next:"Set STRIPE_SECRET_KEY and PRICE_ID_... secrets."},{status:501});
});
