import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY")!;
const MODEL = Deno.env.get("OPENAI_MODEL") || "gpt-5.6-luna";

const TYPE_ENUM = ["Görev","Fatura","Abonelik","Randevu","Belge","Garanti","Bakım","Diğer"];
const PRIORITY_ENUM = ["Normal","Önemli","Acil"];
const REPEAT_ENUM = ["","daily","weekly","monthly","yearly"];
const REMINDER_ENUM = [0,15,60,1440,2880,10080];

const schema = {
  type: "object",
  additionalProperties: false,
  properties: {
    title: { type: "string", description: "Kısa, temiz görev başlığı; gereksiz tarih/saat ifadelerini başlıktan çıkar." },
    type: { type: "string", enum: TYPE_ENUM },
    priority: { type: "string", enum: PRIORITY_ENUM },
    date: { type: ["string","null"], description: "YYYY-MM-DD veya null." },
    time: { type: ["string","null"], description: "HH:mm veya null." },
    repeat: { type: "string", enum: REPEAT_ENUM },
    recurrence_kind: { type: ["string","null"], enum: ["daily","weekly","monthly","yearly","last_business_day","date_interval","none",null] },
    recurrence_config: { type: ["object","null"], additionalProperties: false, properties: { interval: {type:["integer","null"]}, weekday: {type:["integer","null"]}, day_of_month: {type:["integer","null"]}, anchor: {type:["string","null"]} } },
    reminder_offset_minutes: { type: "integer", enum: REMINDER_ENUM },
    note: { type: "string" },
    needs_clarification: { type: "boolean" },
    clarifying_question: { type: "string", description: "Tek, kısa Türkçe soru; gerekmiyorsa boş string." },
    warnings: { type: "array", items: { type: "string" } }
  },
  required: ["title","type","priority","date","time","repeat","recurrence_kind","recurrence_config","reminder_offset_minutes","note","needs_clarification","clarifying_question","warnings"]
};

const json = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });

Deno.serve(async (req) => {
  try {
    if (req.method !== "POST") return json(405, { error: "Method not allowed" });
    if (!OPENAI_API_KEY) return json(503, { error: "OPENAI_API_KEY missing" });

    const auth = req.headers.get("Authorization");
    if (!auth) return json(401, { error: "Unauthorized" });

    const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: auth } }
    });
    const { data: userData, error: userError } = await supabase.auth.getUser();
    if (userError || !userData.user) return json(401, { error: "Unauthorized" });

    const body = await req.json().catch(() => null);
    const text = String(body?.text || "").trim();
    const timezone = String(body?.timezone || "Europe/Istanbul");
    const locale = String(body?.locale || "tr-TR");
    const now = String(body?.now || new Date().toISOString());
    if (!text || text.length > 1200) return json(400, { error: "Text must be 1-1200 characters." });

    const instructions = `
Sen Unutmam uygulamasının Türkçe akıllı hatırlatıcı yorumlayıcısısın.
Kullanıcının doğal cümlesini güvenilir biçimde yapılandır.

Bağlam:
- Şu an: ${now}
- Zaman dilimi: ${timezone}
- Dil: ${locale}

Kurallar:
- Göreli tarihleri mutlak tarihe çevir; açık tarihleri koru.
- Tarih veya saat açık değilse gereksiz kesinlik uydurma.
- "yarın", "3 gün sonra", "gelecek pazartesi", "12 Ekim", "önümüzdeki ay" gibi ifadeleri yorumla.
- "akşam/sabah" gibi kaba zaman ifadelerinde saat açık değilse time=null bırak.
- Kullanıcı açıkça hatırlatma istiyor ama kritik tarih/saat eksikse needs_clarification=true yap ve tek kısa soru sor.
- Tarihsiz sıradan bir not/görev için clarification zorunlu değil.
- reminder_offset_minutes yalnızca kullanıcı açıkça ön süre verdiyse veya makul bir uygulama önerisi gerekiyorsa kullan; aksi halde 0.
- Title kısa ve görev odaklı olsun.
- Şüpheli bilgiyi uydurma; warning alanını kullan.
- "her ayın son iş günü" ifadesini recurrence_kind=last_business_day ve recurrence_config={"anchor":"month_end_business_day"} olarak yapılandır.
- "maaş yatınca" veya başka bir dış olaya bağlı zaman ifadesinde, uygulamada doğrulanabilir bir olay kaynağı yoksa tarihi uydurma; needs_clarification=true yap ve kısa soru sor.
`;

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: MODEL,
        reasoning: { effort: "low" },
        instructions,
        input: `Kullanıcı cümlesi:\n${text}`,
        text: {
          format: {
            type: "json_schema",
            name: "unutmam_reminder",
            strict: true,
            schema
          }
        }
      })
    });

    if (!response.ok) return json(502, { error: "OpenAI request failed", detail: (await response.text()).slice(0, 1000) });
    const payload = await response.json();
    if (!payload?.output_text) return json(502, { error: "OpenAI returned no output_text" });

    return json(200, { result: JSON.parse(payload.output_text), model: MODEL });
  } catch (err) {
    return json(500, { error: err instanceof Error ? err.message : "Unknown error" });
  }
});
