-- Unutmam v4 Supabase schema
create extension if not exists pgcrypto;

create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  timezone text not null default 'Europe/Istanbul',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 500),
  note text,
  item_type text not null default 'Görev',
  priority text not null default 'Normal',
  due_at timestamptz,
  repeat_rule text,
  done boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists items_user_due_idx on items(user_id,due_at);
create index if not exists items_due_open_idx on items(due_at) where done=false;

create table if not exists device_tokens (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  endpoint text not null,
  p256dh text,
  auth text,
  platform text,
  created_at timestamptz not null default now(),
  unique(user_id, endpoint)
);

create table if not exists shares (
  id uuid primary key default gen_random_uuid(),
  item_id uuid not null references items(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  invite_code text unique not null,
  created_at timestamptz not null default now(),
  expires_at timestamptz
);

alter table profiles enable row level security;
alter table items enable row level security;
alter table device_tokens enable row level security;
alter table shares enable row level security;

drop policy if exists profiles_select_own on profiles;
create policy profiles_select_own on profiles for select to authenticated using ((select auth.uid())=id);
drop policy if exists profiles_insert_own on profiles;
create policy profiles_insert_own on profiles for insert to authenticated with check ((select auth.uid())=id);
drop policy if exists profiles_update_own on profiles;
create policy profiles_update_own on profiles for update to authenticated using ((select auth.uid())=id) with check ((select auth.uid())=id);

drop policy if exists items_select_own on items;
create policy items_select_own on items for select to authenticated using ((select auth.uid())=user_id);
drop policy if exists items_insert_own on items;
create policy items_insert_own on items for insert to authenticated with check ((select auth.uid())=user_id);
drop policy if exists items_update_own on items;
create policy items_update_own on items for update to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
drop policy if exists items_delete_own on items;
create policy items_delete_own on items for delete to authenticated using ((select auth.uid())=user_id);

drop policy if exists device_select_own on device_tokens;
create policy device_select_own on device_tokens for select to authenticated using ((select auth.uid())=user_id);
drop policy if exists device_insert_own on device_tokens;
create policy device_insert_own on device_tokens for insert to authenticated with check ((select auth.uid())=user_id);
drop policy if exists device_delete_own on device_tokens;
create policy device_delete_own on device_tokens for delete to authenticated using ((select auth.uid())=user_id);

drop policy if exists shares_select_own on shares;
create policy shares_select_own on shares for select to authenticated using ((select auth.uid())=owner_id);
drop policy if exists shares_insert_own on shares;
create policy shares_insert_own on shares for insert to authenticated with check ((select auth.uid())=owner_id);
drop policy if exists shares_delete_own on shares;
create policy shares_delete_own on shares for delete to authenticated using ((select auth.uid())=owner_id);

-- Auto-create a profile on signup
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id) values (new.id) on conflict do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();
