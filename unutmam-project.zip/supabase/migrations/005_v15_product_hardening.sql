-- Unutmam V15: product hardening, search, family sharing, native devices,
-- calendar links, subscriptions, AI usage, auditing and deletion requests.

create extension if not exists pgcrypto;

-- Richer recurrence and search.
alter table items add column if not exists list_id uuid;
alter table items add column if not exists repeat_rule_json jsonb;
alter table items add column if not exists timezone text not null default 'Europe/Istanbul';
alter table items add column if not exists source text not null default 'manual';
alter table items add column if not exists external_calendar_event_id text;
alter table items add column if not exists archived_at timestamptz;

create index if not exists items_user_updated_idx on items(user_id, updated_at desc);
create index if not exists items_user_open_due_idx on items(user_id, done, due_at);
create index if not exists items_user_archived_idx on items(user_id, archived_at);

-- Fast text search.
alter table items add column if not exists search_vector tsvector
  generated always as (
    to_tsvector('simple', coalesce(title,'') || ' ' || coalesce(note,''))
  ) stored;
create index if not exists items_search_vector_gin on items using gin(search_vector);

-- Lists / family spaces.
create table if not exists lists (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 120),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists list_members (
  list_id uuid not null references lists(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','member')),
  created_at timestamptz not null default now(),
  primary key (list_id,user_id)
);

create index if not exists list_members_user_idx on list_members(user_id);

-- Native/web device subscriptions.
alter table device_tokens add column if not exists token_type text not null default 'push';
alter table device_tokens add column if not exists app_version text;
alter table device_tokens add column if not exists last_seen_at timestamptz not null default now();
alter table device_tokens add column if not exists enabled boolean not null default true;
create index if not exists device_tokens_active_idx on device_tokens(user_id,enabled,last_seen_at desc);

-- Share invitations.
alter table shares add column if not exists list_id uuid references lists(id) on delete cascade;
alter table shares add column if not exists invited_email text;
alter table shares add column if not exists accepted_by uuid references auth.users(id) on delete set null;
alter table shares add column if not exists accepted_at timestamptz;
create index if not exists shares_list_idx on shares(list_id);

-- Calendar connectors.
create table if not exists calendar_connections (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  provider text not null check (provider in ('google','apple','device')),
  account_label text,
  encrypted_refresh_token text,
  calendar_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(user_id, provider, account_label)
);
alter table calendar_connections enable row level security;
drop policy if exists calendar_connections_select_own on calendar_connections;
create policy calendar_connections_select_own on calendar_connections for select to authenticated
using ((select auth.uid())=user_id);
drop policy if exists calendar_connections_insert_own on calendar_connections;
create policy calendar_connections_insert_own on calendar_connections for insert to authenticated
with check ((select auth.uid())=user_id);
drop policy if exists calendar_connections_update_own on calendar_connections;
create policy calendar_connections_update_own on calendar_connections for update to authenticated
using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
drop policy if exists calendar_connections_delete_own on calendar_connections;
create policy calendar_connections_delete_own on calendar_connections for delete to authenticated
using ((select auth.uid())=user_id);

-- Billing / entitlements.
create table if not exists subscriptions (
  user_id uuid primary key references auth.users(id) on delete cascade,
  provider text not null default 'stripe',
  customer_id text,
  subscription_id text,
  status text not null default 'inactive',
  plan text not null default 'free',
  current_period_end timestamptz,
  cancel_at_period_end boolean not null default false,
  updated_at timestamptz not null default now()
);
alter table subscriptions enable row level security;
drop policy if exists subscriptions_select_own on subscriptions;
create policy subscriptions_select_own on subscriptions for select to authenticated
using ((select auth.uid())=user_id);

-- AI usage metering.
create table if not exists ai_usage_daily (
  user_id uuid not null references auth.users(id) on delete cascade,
  usage_date date not null default current_date,
  requests integer not null default 0,
  input_chars integer not null default 0,
  primary key(user_id, usage_date)
);
alter table ai_usage_daily enable row level security;
drop policy if exists ai_usage_select_own on ai_usage_daily;
create policy ai_usage_select_own on ai_usage_daily for select to authenticated
using ((select auth.uid())=user_id);

-- Minimal audit trail (no raw reminder text).
create table if not exists audit_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  event_type text not null,
  entity_id uuid,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists audit_events_user_created_idx on audit_events(user_id, created_at desc);
alter table audit_events enable row level security;
drop policy if exists audit_events_select_own on audit_events;
create policy audit_events_select_own on audit_events for select to authenticated
using ((select auth.uid())=user_id);

-- Deletion requests are server-driven; users can create a request.
create table if not exists deletion_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique not null references auth.users(id) on delete cascade,
  requested_at timestamptz not null default now(),
  processed_at timestamptz,
  status text not null default 'pending'
);
alter table deletion_requests enable row level security;
drop policy if exists deletion_requests_select_own on deletion_requests;
create policy deletion_requests_select_own on deletion_requests for select to authenticated
using ((select auth.uid())=user_id);
drop policy if exists deletion_requests_insert_own on deletion_requests;
create policy deletion_requests_insert_own on deletion_requests for insert to authenticated
with check ((select auth.uid())=user_id);

-- RLS for lists and members.
alter table lists enable row level security;
alter table list_members enable row level security;

drop policy if exists lists_select_member on lists;
create policy lists_select_member on lists for select to authenticated
using (
  owner_id=(select auth.uid())
  or exists (
    select 1 from list_members lm
    where lm.list_id=lists.id and lm.user_id=(select auth.uid())
  )
);

drop policy if exists lists_insert_owner on lists;
create policy lists_insert_owner on lists for insert to authenticated
with check (owner_id=(select auth.uid()));

drop policy if exists lists_update_owner on lists;
create policy lists_update_owner on lists for update to authenticated
using (owner_id=(select auth.uid())) with check (owner_id=(select auth.uid()));

drop policy if exists lists_delete_owner on lists;
create policy lists_delete_owner on lists for delete to authenticated
using (owner_id=(select auth.uid()));

drop policy if exists list_members_select_member on list_members;
create policy list_members_select_member on list_members for select to authenticated
using (
  user_id=(select auth.uid())
  or exists (
    select 1 from lists l where l.id=list_members.list_id and l.owner_id=(select auth.uid())
  )
);

drop policy if exists list_members_insert_owner on list_members;
create policy list_members_insert_owner on list_members for insert to authenticated
with check (
  exists (select 1 from lists l where l.id=list_members.list_id and l.owner_id=(select auth.uid()))
);

drop policy if exists list_members_delete_owner on list_members;
create policy list_members_delete_owner on list_members for delete to authenticated
using (
  user_id=(select auth.uid())
  or exists (select 1 from lists l where l.id=list_members.list_id and l.owner_id=(select auth.uid()))
);

-- Replace item policies with list-aware rules.
drop policy if exists items_select_own on items;
drop policy if exists items_insert_own on items;
drop policy if exists items_update_own on items;
drop policy if exists items_delete_own on items;

create policy items_select_v15 on items for select to authenticated
using (
  user_id=(select auth.uid())
  or (
    list_id is not null and exists (
      select 1 from list_members lm
      where lm.list_id=items.list_id and lm.user_id=(select auth.uid())
    )
  )
);

create policy items_insert_v15 on items for insert to authenticated
with check (
  user_id=(select auth.uid())
  and (
    list_id is null
    or exists (
      select 1 from list_members lm
      where lm.list_id=items.list_id and lm.user_id=(select auth.uid())
    )
  )
);

create policy items_update_v15 on items for update to authenticated
using (
  user_id=(select auth.uid())
  or (
    list_id is not null and exists (
      select 1 from list_members lm
      where lm.list_id=items.list_id and lm.user_id=(select auth.uid())
    )
  )
)
with check (
  user_id=(select auth.uid())
  or (
    list_id is not null and exists (
      select 1 from list_members lm
      where lm.list_id=items.list_id and lm.user_id=(select auth.uid())
    )
  )
);

create policy items_delete_v15 on items for delete to authenticated
using (
  user_id=(select auth.uid())
  or (
    list_id is not null and exists (
      select 1 from lists l
      where l.id=items.list_id and l.owner_id=(select auth.uid())
    )
  )
);

-- Helpful RPC for deleting a user account. The auth user deletion must be done server-side
-- after this function completes; this only ensures application rows are cascaded.
create or replace function public.request_account_deletion()
returns uuid
language plpgsql
security invoker
as $$
declare rid uuid;
begin
  insert into public.deletion_requests(user_id)
  values ((select auth.uid()))
  on conflict(user_id) do update set requested_at=now(), status='pending', processed_at=null
  returning id into rid;
  return rid;
end $$;
