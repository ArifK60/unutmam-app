-- Unutmam V15.2 production hardening
-- Idempotent reminder delivery with leases/retries and safe offline sync support.
alter table reminder_deliveries
  add column if not exists attempt_count integer not null default 0,
  add column if not exists locked_at timestamptz,
  add column if not exists lock_token uuid,
  add column if not exists next_attempt_at timestamptz not null default now();

create index if not exists reminder_deliveries_claim_idx
  on reminder_deliveries(status, next_attempt_at, scheduled_for);

-- Server-only atomic claim. The worker gets exactly one active lease for a delivery.
create or replace function public.claim_reminder_delivery(p_delivery_id uuid, p_lock_token uuid)
returns public.reminder_deliveries
language plpgsql
security definer
set search_path = public
as $$
declare r public.reminder_deliveries;
begin
  update public.reminder_deliveries
     set status='processing',
         attempt_count=attempt_count+1,
         locked_at=now(),
         lock_token=p_lock_token
   where id=p_delivery_id
     and (
       status='pending'
       or (status='processing' and locked_at < now() - interval '5 minutes')
     )
     and next_attempt_at <= now()
   returning * into r;
  return r;
end;
$$;

revoke all on function public.claim_reminder_delivery(uuid,uuid) from public, anon, authenticated;

-- Automatic updated_at keeps offline conflict resolution deterministic.
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists items_set_updated_at on public.items;
create trigger items_set_updated_at before update on public.items
for each row execute function public.set_updated_at();

drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at before update on public.profiles
for each row execute function public.set_updated_at();

drop trigger if exists lists_set_updated_at on public.lists;
create trigger lists_set_updated_at before update on public.lists
for each row execute function public.set_updated_at();

drop trigger if exists calendar_connections_set_updated_at on public.calendar_connections;
create trigger calendar_connections_set_updated_at before update on public.calendar_connections
for each row execute function public.set_updated_at();

drop trigger if exists subscriptions_set_updated_at on public.subscriptions;
create trigger subscriptions_set_updated_at before update on public.subscriptions
for each row execute function public.set_updated_at();

-- Prevent invite-code reuse and keep expired invites queryable.
create index if not exists shares_invite_expires_idx on public.shares(invite_code, expires_at);

-- Soft-delete tombstones prevent an offline deletion from being resurrected later.
alter table public.items add column if not exists deleted_at timestamptz;
create index if not exists items_user_deleted_idx on public.items(user_id, deleted_at);
