-- Unutmam V6: AI parsing + reminder delivery tracking
alter table items
  add column if not exists reminder_offset_minutes integer not null default 0
  check (reminder_offset_minutes between 0 and 525600);

create table if not exists reminder_deliveries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  item_id uuid not null references items(id) on delete cascade,
  scheduled_for timestamptz not null,
  channel text not null default 'push',
  status text not null default 'pending',
  sent_at timestamptz,
  provider_message_id text,
  error text,
  created_at timestamptz not null default now(),
  unique(item_id, scheduled_for, channel)
);

create index if not exists reminder_deliveries_due_idx
  on reminder_deliveries(status, scheduled_for);

alter table reminder_deliveries enable row level security;

drop policy if exists reminder_deliveries_select_own on reminder_deliveries;
create policy reminder_deliveries_select_own
  on reminder_deliveries for select to authenticated
  using ((select auth.uid())=user_id);

drop policy if exists reminder_deliveries_insert_own on reminder_deliveries;
create policy reminder_deliveries_insert_own
  on reminder_deliveries for insert to authenticated
  with check ((select auth.uid())=user_id);

drop policy if exists reminder_deliveries_update_own on reminder_deliveries;
create policy reminder_deliveries_update_own
  on reminder_deliveries for update to authenticated
  using ((select auth.uid())=user_id)
  with check ((select auth.uid())=user_id);

-- The server-side worker uses the service role and can manage delivery rows.
