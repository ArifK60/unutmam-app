-- Unutmam V15.3: security hardening + deterministic recurrence metadata.

-- Owners must always be members of their own lists.
create or replace function public.ensure_list_owner_member()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  insert into public.list_members(list_id,user_id,role)
  values (new.id,new.owner_id,'owner')
  on conflict (list_id,user_id) do update set role='owner';
  return new;
end;
$$;

drop trigger if exists lists_owner_member on public.lists;
create trigger lists_owner_member after insert on public.lists
for each row execute function public.ensure_list_owner_member();

-- Ownership and the item's original user cannot be changed through ordinary updates.
create or replace function public.prevent_identity_escalation()
returns trigger language plpgsql
as $$
begin
  if new.user_id <> old.user_id then
    raise exception 'item user_id is immutable';
  end if;
  if new.list_id is distinct from old.list_id then
    if not (old.list_id is null and new.list_id is not null) then
      raise exception 'item list_id cannot be changed after creation';
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists items_identity_guard on public.items;
create trigger items_identity_guard before update on public.items
for each row execute function public.prevent_identity_escalation();

-- A member may edit shared content, but cannot promote themselves or alter list ownership.
drop policy if exists list_members_update_owner on list_members;
create policy list_members_update_owner on list_members for update to authenticated
using (
  exists (select 1 from lists l where l.id=list_members.list_id and l.owner_id=(select auth.uid()))
)
with check (
  exists (select 1 from lists l where l.id=list_members.list_id and l.owner_id=(select auth.uid()))
);

-- Explicit recurrence metadata accepted by the parser/UI. The scheduler must honor these kinds.
alter table public.items add column if not exists recurrence_kind text;
alter table public.items add column if not exists recurrence_config jsonb;
alter table public.items add constraint items_recurrence_kind_check
check (recurrence_kind is null or recurrence_kind in ('daily','weekly','monthly','yearly','last_business_day','date_interval','none'));
create index if not exists items_recurrence_idx on public.items(recurrence_kind,due_at) where done=false and deleted_at is null;

-- Worker-visible delivery queries should never see deleted items.
create index if not exists items_worker_due_idx
on public.items(done, archived_at, deleted_at, due_at)
where done=false and archived_at is null and deleted_at is null;
