# Unutmam V15 — Product Master

**Aklına geleni yaz. Gerisini unutma.**

Bu paket V6'nın üzerine V7 → V15 yol haritasını tek geliştirme ağacında toplar.

## İçerik
- `frontend/` — Web/PWA
- `mobile/` — Capacitor 8 Android/iOS proje kabuğu
- `supabase/` — migrations + Edge Functions
- `tests/` — parser senaryoları
- `docs/` — mimari, deploy, mağaza, gizlilik, fiyatlama

## V15'te eklenenler
- FCM HTTP v1 tabanlı push worker
- native push / local notification bridge
- sesli giriş
- arama / filtre
- zengin tekrar modeli için JSON alanı
- aile listeleri / üyelik / davet kodu
- cihaz takvimi + ICS
- Google Calendar OAuth iskeleti
- AI kullanım ölçümü
- audit
- hesap silme talebi
- Stripe abonelik iskeleti
- mağaza ve gizlilik dokümanları

## Önemli
Bu bir **üretim geliştirme paketi**dir; tek başına canlı servis değildir. Gerçek deployment için Supabase/Firebase/Apple/Google/Stripe hesapları, secret'lar, imzalama ve gerçek cihaz testleri gerekir.

## Güvenlik
Mobil/Web tarafına OpenAI secret, Supabase secret/service-role veya Stripe secret koyulmaz. Supabase dokümantasyonu publishable key'in uygulamalarda kullanılmasını, secret key'in ise yalnızca güvenilen sunucu tarafında tutulmasını önerir.


## V15.2 Production hardening
- Local-first offline queue with online reconciliation.
- Soft-delete tombstones to prevent offline deletion resurrection.
- Timezone-aware due_at serialization/display.
- Idempotent reminder delivery leases/retries.
- Native push registration and deep-link handling scaffold.
- Password reset and account deletion request UI.

The package is still not a store-submitted release: real Supabase/Firebase/APNs credentials, physical-device tests, signing and store review remain external release gates.

## V15.3 hardening
- Shared-list identity escalation guard.
- Automatic owner membership for new lists.
- Deterministic recurrence metadata including last-business-day semantics.
- Authenticated mobile reminders use server push as canonical delivery; local scheduling is fallback only for local/offline-only mode to avoid duplicate notifications.
- Advanced external-event phrases are clarified rather than guessed.

## V15.5 Supabase production hardening
- Removed placeholder cron URLs from migrations.
- Cron installation moved to `scripts/production/install-cron.sql` using Supabase Vault.
- Reminder worker requires `UNUTMAM_CRON_SECRET`.
- Added explicit Edge Function JWT policies and production deployment scripts.

## Android ilk çalıştırma
- `scripts/setup-android.bat` Windows üzerinde bağımlılıkları kurar, Android projesini oluşturur ve Capacitor sync yapar.
- Ayrıntılı cihaz testi: `docs/ANDROID_FIRST_RUN_TR.md`.
