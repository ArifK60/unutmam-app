import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(new URL('..', import.meta.url).pathname);
const required = [
  'supabase/migrations/001_init.sql','supabase/migrations/002_reminder_cron.sql',
  'supabase/migrations/003_v6_ai_and_delivery.sql','supabase/migrations/004_reminder_cron_v6.sql',
  'supabase/migrations/005_v15_product_hardening.sql','supabase/migrations/006_production_hardening.sql',
  'supabase/migrations/007_security_and_recurrence_hardening.sql',
  'supabase/functions/ai-parser/index.ts','supabase/functions/reminder-worker/index.ts',
  'supabase/functions/transcribe/index.ts','mobile/package.json','frontend/index.html'
];
const missing = required.filter(f=>!fs.existsSync(path.join(root,f)));
const functionDirs = fs.readdirSync(path.join(root,'supabase/functions'),{withFileTypes:true})
  .filter(d=>d.isDirectory()).map(d=>d.name).sort();
const forbidden = [];
for (const f of ['frontend/config.js','mobile/public/config.js']) {
  const p=path.join(root,f); if (fs.existsSync(p)) {
    const s=fs.readFileSync(p,'utf8');
    if (/sk-[A-Za-z0-9_-]{20,}/.test(s) || /service_role/i.test(s)) forbidden.push(`${f}: possible secret in client config`);
  }
}
const out={ok:missing.length===0&&forbidden.length===0,missing,forbidden,functionDirs};
console.log(JSON.stringify(out,null,2));
process.exit(out.ok?0:1);
