$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$mobile = Join-Path $root 'mobile'
Set-Location $mobile
Write-Host '=== UNUTMAM ANDROID SETUP ===' -ForegroundColor Cyan
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Node.js bulunamadı. Node.js 20+ LTS kur.' }
if (-not (Get-Command npm -ErrorAction SilentlyContinue)) { throw 'npm bulunamadı.' }
Write-Host "Node: $(node --version)"
Write-Host "npm : $(npm --version)"
if (-not (Test-Path 'node_modules')) { npm install }
if (-not (Test-Path 'android')) { npx cap add android }
npm run build
npx cap sync android
Write-Host 'Android proje hazır. Android Studio ile açmak için: npx cap open android' -ForegroundColor Green
Write-Host 'Debug APK için Android Studio > Build > Build APK(s).' -ForegroundColor Yellow
