-- Run AFTER migrations and Edge Functions are deployed.
-- Store project_url and cron_secret in Supabase Vault first.
-- select vault.create_secret('https://YOUR_PROJECT_REF.supabase.co', 'project_url');
-- select vault.create_secret('GENERATE_A_LONG_RANDOM_SECRET', 'cron_secret');

select cron.unschedule('unutmam-reminder-worker')
where exists (select 1 from cron.job where jobname = 'unutmam-reminder-worker');

select cron.schedule(
  'unutmam-reminder-worker', '* * * * *', $$
  select net.http_post(
    url := (select decrypted_secret from vault.decrypted_secrets where name = 'project_url') || '/functions/v1/reminder-worker',
    headers := jsonb_build_object('Content-Type','application/json','x-unutmam-cron-secret',(select decrypted_secret from vault.decrypted_secrets where name = 'cron_secret')),
    body := jsonb_build_object('run_at', now())
  );
  $$
);
