# Production secrets

Required Edge Function secrets:
- OPENAI_API_KEY
- FCM_PROJECT_ID
- FCM_CLIENT_EMAIL
- FCM_PRIVATE_KEY
- UNUTMAM_CRON_SECRET

Optional:
- OPENAI_MODEL
- OPENAI_TRANSCRIBE_MODEL
- GOOGLE_CLIENT_ID
- GOOGLE_REDIRECT_URI
- STRIPE_SECRET_KEY
- STRIPE_WEBHOOK_SECRET

Do not create custom secrets beginning with `SUPABASE_`; that prefix is reserved by Supabase. Never commit secret values.

## Google Calendar production secrets
- `GOOGLE_CLIENT_ID`
- `GOOGLE_CLIENT_SECRET`
- `GOOGLE_REDIRECT_URI` — must point to the deployed `calendar-google-callback` function.
- `GOOGLE_OAUTH_STATE_SECRET` — long random secret used to sign short-lived OAuth state.
- `CALENDAR_TOKEN_ENCRYPTION_KEY` — 32-byte base64 key used for AES-256-GCM refresh-token encryption.

Generate a 32-byte key locally with:
`openssl rand -base64 32`

Never commit any of the above values to the repository.
