@echo off
setlocal
powershell -ExecutionPolicy Bypass -File "%~dp0setup-android.ps1"
if errorlevel 1 (
  echo.
  echo KURULUM BASARISIZ. Yukaridaki hatayi kontrol edin.
  pause
  exit /b 1
)
echo.
echo UNUTMAM Android projesi hazir.
pause
