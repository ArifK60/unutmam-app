// Copy to config.js and fill these values from your Supabase project.
// Never put OPENAI_API_KEY or a Supabase service-role key in this file.
window.UNUTMAM_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
  SUPABASE_PUBLISHABLE_KEY: "YOUR_PUBLISHABLE_KEY",
  AI_PARSER_ENABLED: true
};
