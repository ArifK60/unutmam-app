import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.unutmam.app',
  appName: 'Unutmam',
  webDir: 'dist',
  bundledWebRuntime: false,
  plugins: {
    PushNotifications: {
      presentationOptions: ['badge','sound','banner','list']
    }
  },
  ios: {
    contentInset: 'automatic'
  }
};
export default config;
