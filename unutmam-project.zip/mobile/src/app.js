import { createClient } from "@supabase/supabase-js";
import { Capacitor } from "@capacitor/core";
import { PushNotifications } from "@capacitor/push-notifications";
import { LocalNotifications } from "@capacitor/local-notifications";
import { Calendar } from "@capacitor/calendar";
import { Share } from "@capacitor/share";

const cfg=window.UNUTMAM_CONFIG||{};
const nativePlatform=Capacitor.getPlatform();
const isNative=Capacitor.isNativePlatform();
const cloudEnabled=/^https:\/\/.+\.supabase\.co(m)?$/.test(cfg.SUPABASE_URL||"")&&!!cfg.SUPABASE_PUBLISHABLE_KEY&&!cfg.SUPABASE_PUBLISHABLE_KEY.includes("YOUR_");
export const supabase=cloudEnabled?createClient(cfg.SUPABASE_URL,cfg.SUPABASE_PUBLISHABLE_KEY):null;

const KEY="unutmam.items.v6";
let items=JSON.parse(localStorage.getItem(KEY)||"[]"),session=null,pending=null,clarifyBase=null,authMode="login";
const $=id=>document.getElementById(id);
const uid=()=>crypto.randomUUID?crypto.randomUUID():Date.now()+"-"+Math.random();
const nowDate=new Date();
const today=()=>{const d=new Date();return new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,10)};
const iso=d=>new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,10);
const months={ocak:0,şubat:1,mart:2,nisan:3,mayıs:4,haziran:5,temmuz:6,ağustos:7,eylül:8,ekim:9,kasım:10,aralık:11};
const allowedTypes=["Görev","Fatura","Abonelik","Randevu","Belge","Garanti","Bakım","Diğer"];
const allowedPriorities=["Normal","Önemli","Acil"];
const REMINDER_LABELS={0:"Zamanı gelince",15:"15 dk önce",60:"1 saat önce",1440:"1 gün önce",2880:"2 gün önce",10080:"1 hafta önce"};

function save(){localStorage.setItem(KEY,JSON.stringify(items))}
function toast(msg){const el=$("toast");el.textContent=msg;el.hidden=false;clearTimeout(toast.t);toast.t=setTimeout(()=>el.hidden=true,2200)}
function normalizeDateValue(v){return /^\d{4}-\d{2}-\d{2}$/.test(v||"")?v:""}
function normalizeTimeValue(v){return /^\d{2}:\d{2}$/.test(v||"")?v:""}
function parseDate(t){
 t=t.toLocaleLowerCase("tr-TR");const now=new Date(),base=new Date(now.getFullYear(),now.getMonth(),now.getDate());
 if(/\bbugün\b/.test(t))return iso(base);
 if(/\byarın\b/.test(t)){const d=new Date(base);d.setDate(d.getDate()+1);return iso(d)}
 if(/\b(öbür gün|öbürgün)\b/.test(t)){const d=new Date(base);d.setDate(d.getDate()+2);return iso(d)}
 if(/\bbu hafta\b/.test(t)){const d=new Date(base),day=d.getDay()||7;d.setDate(d.getDate()+(day===1?0:8-day));return iso(d)}
 let m=t.match(/(\d+)\s*(gün|hafta|ay|yıl)\s*sonra/);
 if(m){const n=+m[1],d=new Date(base);if(m[2]==="gün")d.setDate(d.getDate()+n);if(m[2]==="hafta")d.setDate(d.getDate()+7*n);if(m[2]==="ay")d.setMonth(d.getMonth()+n);if(m[2]==="yıl")d.setFullYear(d.getFullYear()+n);return iso(d)}
 for(const [name,idx] of Object.entries(months)){m=t.match(new RegExp("(\\d{1,2})\\s*"+name+"(?:\\s*(\\d{4}))?"));if(m){const d=new Date(m[2]?+m[2]:now.getFullYear(),idx,+m[1]);if(!m[2]&&d<base)d.setFullYear(d.getFullYear()+1);return iso(d)}}
 m=t.match(/\b(\d{1,2})[./-](\d{1,2})(?:[./-](\d{4}))?\b/);
 if(m){const d=new Date(m[3]?+m[3]:now.getFullYear(),+m[2]-1,+m[1]);if(!m[3]&&d<base)d.setFullYear(d.getFullYear()+1);return iso(d)}
 return "";
}
function parseTime(t){
 let m=t.match(/\b([01]?\d|2[0-3])[:.](\d{2})\b/);if(m)return m[1].padStart(2,"0")+":"+m[2];
 m=t.match(/\b(saat|saatinde|de|da)\s*([01]?\d|2[0-3])\b/);if(m)return m[2].padStart(2,"0")+":00";
 return "";
}
function guessType(t){t=t.toLocaleLowerCase("tr-TR");if(/fatura|elektrik|su fatur|doğalgaz|internet fatur/.test(t))return"Fatura";if(/abonelik|üyelik|netflix|spotify/.test(t))return"Abonelik";if(/doktor|diş|randevu|hastane|muayene/.test(t))return"Randevu";if(/pasaport|ehliyet|kimlik|belge|ruhsat|vize/.test(t))return"Belge";if(/garanti|garantisi/.test(t))return"Garanti";if(/bakım|servis|yağ değiş|lastik|muayene/.test(t))return"Bakım";return"Görev"}
function guessRepeat(t){t=t.toLocaleLowerCase("tr-TR");if(/her gün|günlük/.test(t))return"daily";if(/her hafta|haftalık|haftada bir/.test(t))return"weekly";if(/her ay|aylık|ayda bir/.test(t))return"monthly";if(/her yıl|yıllık|yılda bir/.test(t))return"yearly";return""}
function guessPriority(t){t=t.toLocaleLowerCase("tr-TR");if(/acil|çok önemli|hemen/.test(t))return"Acil";if(/önemli|kritik/.test(t))return"Önemli";return"Normal"}
function cleanTitle(t){
 return t.replace(/\b(bugün|yarın|öbür gün|öbürgün|bu hafta)\b/ig,"")
 .replace(/\b\d+\s*(gün|hafta|ay|yıl)\s*sonra\b/ig,"")
 .replace(/\b\d{1,2}[./-]\d{1,2}(?:[./-]\d{4})?\b/g,"")
 .replace(/\b\d{1,2}\s*(ocak|şubat|mart|nisan|mayıs|haziran|temmuz|ağustos|eylül|ekim|kasım|aralık)(?:\s*\d{4})?\b/ig,"")
 .replace(/\b(saat|saatinde)\s*([01]?\d|2[0-3])(?::\d{2})?\b/ig,"")
 .replace(/\bher (gün|hafta|ay|yıl)\b/ig,"")
 .replace(/\s+/g," ").replace(/^[,.\s]+|[,.\s]+$/g,"").trim();
}
function localInterpret(text){
 const date=parseDate(text),time=parseTime(text),type=guessType(text),repeat=guessRepeat(text),priority=guessPriority(text),low=text.toLocaleLowerCase("tr-TR");
 const warnings=[];let needsClarification=false,clarifying_question="";
 if(!date && /hatırlat|unutma|randevu|toplantı|sınav|uçuş|fatura son|son gün/.test(low)){warnings.push("Tarih belirtilmemiş");needsClarification=true;clarifying_question="Hangi gün hatırlatayım?"}
 if(/randevu|doktor|diş|toplantı|uçak|uçuş|sınav/.test(low)&&!time){warnings.push("Saat belirtilmemiş");needsClarification=true;clarifying_question="Hangi saat için?"}
 return {id:uid(),raw:text,title:cleanTitle(text)||text,date,time,type,repeat,priority,note:"",done:false,created_at:new Date().toISOString(),reminder_offset_minutes:0,needs_clarification:needsClarification,clarifying_question,warnings,source:"local"};
}


async function registerNativePush(){
 if(!isNative||!session)return;
 try{
   let p=await PushNotifications.checkPermissions();
   if(p.receive==="prompt")p=await PushNotifications.requestPermissions();
   if(p.receive!=="granted")return;
   await PushNotifications.createChannel?.({id:"unutmam_reminders",name:"Unutmam Hatırlatıcıları",description:"Zamanı gelen hatırlatıcılar",importance:5,sound:"default"});
   await PushNotifications.register();
   await PushNotifications.addListener("registration",async token=>{
      await supabase.from("device_tokens").upsert({
        user_id:session.user.id,endpoint:token.value,platform:nativePlatform,
        token_type:"native",app_version:"15.6.0",last_seen_at:new Date().toISOString(),enabled:true
      },{onConflict:"user_id,endpoint"});
   });
   await PushNotifications.addListener("registrationError",e=>console.warn("push registration",e));
   await PushNotifications.addListener("pushNotificationActionPerformed",n=>{
      const id=n.notification?.data?.item_id;
      if(id){ const el=document.querySelector(`[data-item-id="${id}"]`); el?.scrollIntoView({behavior:"smooth"}); }
   });
 }catch(e){console.warn("native push unavailable",e)}
}
async function addToDeviceCalendar(x){
 if(!x.date)return toast("Takvim için tarih gerekli.");
 const start=new Date(x.date+"T"+(x.time||"09:00")+":00").getTime();
 const end=start+30*60*1000;
 try{
   if(isNative){
     await Calendar.createEventInteractively({title:x.title,notes:x.note||"",startDate:start,endDate:end,isAllDay:!x.time});
     toast("Takvim açıldı.");
   }else{
     const dt=new Date(start).toISOString().replace(/[-:]/g,"").replace(/\.\\d{3}/,"");
     const de=new Date(end).toISOString().replace(/[-:]/g,"").replace(/\.\\d{3}/,"");
     const ics=`BEGIN:VCALENDAR\\nVERSION:2.0\\nBEGIN:VEVENT\\nDTSTART:${dt}\\nDTEND:${de}\\nSUMMARY:${x.title.replace(/\\n/g," ")}\\nDESCRIPTION:${(x.note||"").replace(/\\n/g," ")}\\nEND:VEVENT\\nEND:VCALENDAR`;
     const blob=new Blob([ics],{type:"text/calendar"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="unutmam.ics";a.click();URL.revokeObjectURL(a.href);
     toast("Takvim dosyası oluşturuldu.");
   }
 }catch(e){toast("Takvime ekleme iptal edildi.")}
}
async function shareItem(x){
 try{
   const text=`Unutmam: ${x.title}${x.date?` — ${fmt(x)}`:""}`;
   if(isNative) await Share.share({title:"Unutmam",text,url:"https://unutmam.app"});
   else if(navigator.share) await navigator.share({title:"Unutmam",text,url:"https://unutmam.app"});
   else navigator.clipboard?.writeText(text).then(()=>toast("Panoya kopyalandı."));
 }catch{}
}

async function aiEnabled(){
 return !!cfg.AI_PARSER_ENABLED && !!supabase && session && localStorage.getItem("unutmam.ai.enabled.v6")!=="false";
}
async function aiInterpret(text){
 const tz=Intl.DateTimeFormat().resolvedOptions().timeZone||"Europe/Istanbul";
 if(!await aiEnabled())return null;
 const btn=$("addQuick"),old=btn.textContent;btn.textContent="AI...";$("addQuick").disabled=true;
 try{
   const {data,error}=await supabase.functions.invoke("ai-parser",{body:{text,timezone:tz,locale:"tr-TR",now:new Date().toISOString()}});
   if(error)throw error;
   const d=data?.result;
   if(!d)throw new Error("AI cevabı boş");
   const out={
     id:uid(),raw:text,title:(d.title||text).trim(),date:normalizeDateValue(d.date),time:normalizeTimeValue(d.time),
     type:allowedTypes.includes(d.type)?d.type:"Görev",priority:allowedPriorities.includes(d.priority)?d.priority:"Normal",
     repeat:["","daily","weekly","monthly","yearly"].includes(d.repeat)?d.repeat:"",
     reminder_offset_minutes:[0,15,60,1440,2880,10080].includes(Number(d.reminder_offset_minutes))?Number(d.reminder_offset_minutes):0,
     note:d.note||"",done:false,created_at:new Date().toISOString(),
     needs_clarification:!!d.needs_clarification,clarifying_question:d.clarifying_question||"",warnings:Array.isArray(d.warnings)?d.warnings:[],source:"ai"
   };
   return out;
 }catch(e){
   console.warn("AI parser failed",e);
   toast("AI yorumlanamadı; yerel yorumlamaya geçtim.");
   return null;
 }finally{$("addQuick").disabled=false;btn.textContent=old}
}
function labelRepeat(r){return({daily:"Her gün",weekly:"Her hafta",monthly:"Her ay",yearly:"Her yıl"})[r]||"Yok"}
function reminderLabel(n){return REMINDER_LABELS[Number(n)]||"Zamanı gelince"}
function fmt(x){if(!x.date)return"Tarih yok";const d=new Date(x.date+"T00:00:00");return d.toLocaleDateString("tr-TR",{day:"numeric",month:"short",year:"numeric"})+(x.time?" • "+x.time:"")}
function fmtReminder(x){return x.date?"↳ "+reminderLabel(x.reminder_offset_minutes):""}
function dbRow(x){let due_at=null;if(x.date)due_at=x.date+"T"+(x.time||"00:00")+":00";return{id:x.id,user_id:session.user.id,title:x.title,note:x.note||null,item_type:x.type,priority:x.priority,due_at,repeat_rule:x.repeat||null,done:x.done,reminder_offset_minutes:Number(x.reminder_offset_minutes)||0}}
function apiRow(x){return{id:x.id,title:x.title,note:x.note||"",type:x.item_type,priority:x.priority,date:x.due_at?x.due_at.slice(0,10):"",time:x.due_at?x.due_at.slice(11,16):"",repeat:x.repeat_rule||"",reminder_offset_minutes:Number(x.reminder_offset_minutes)||0,done:x.done,created_at:x.created_at}}
async function load(){
 if(!supabase){render();return}
 const {data,error}=await supabase.from("items").select("*").order("due_at",{ascending:true,nullsFirst:false});
 if(error){console.error(error);toast("Bulut kayıtları alınamadı.");render();return}
 items=(data||[]).map(apiRow);save();render()
}
async function upsert(x){
 const clean={...x};delete clean.warnings;delete clean.raw;delete clean.needs_clarification;delete clean.clarifying_question;delete clean.source;
 if(!supabase||!session){items.unshift(clean);save();render();toast("Kaydedildi.");return}
 const {error}=await supabase.from("items").upsert(dbRow(clean));
 if(error)return alert("Buluta kaydedilemedi: "+error.message);
 await load();toast("Buluta kaydedildi.")
}
async function remove(x){
 if(supabase&&session){const {error}=await supabase.from("items").delete().eq("id",x.id);if(error)return alert(error.message)}
 items=items.filter(i=>i.id!==x.id);save();render();toast("Silindi.")
}
function nextDate(x){
 if(!x.repeat||!x.date)return x.date;const d=new Date(x.date+"T00:00:00");
 if(x.repeat==="daily")d.setDate(d.getDate()+1);if(x.repeat==="weekly")d.setDate(d.getDate()+7);
 if(x.repeat==="monthly")d.setMonth(d.getMonth()+1);if(x.repeat==="yearly")d.setFullYear(d.getFullYear()+1);return iso(d)
}
async function toggle(x){if(x.repeat&&!x.done)x.date=nextDate(x);else x.done=!x.done;await upsert(x)}
function render(){
 const t=today(),active=items.filter(x=>!x.done);$("todayCount").textContent=active.filter(x=>x.date===t).length;$("overdueCount").textContent=active.filter(x=>x.date&&x.date<t).length;$("allCount").textContent=items.length;
 const sorted=[...items].sort((a,b)=>(a.done?1:0)-(b.done?1:0)||(a.date||"9999").localeCompare(b.date||"9999"));const list=$("list");list.innerHTML="";
 if(!sorted.length){list.innerHTML='<div class="empty">Henüz kayıt yok.<br>Yukarıdan aklına geleni yaz.</div>';return}
 for(const x of sorted.slice(0,100)){
   const c=document.createElement("div");c.className="card "+(x.done?"done":"");
   c.innerHTML='<button class="check">'+(x.done?"✓":"")+'</button><div class="body"><div class="title"></div><div class="meta"><span class="tag type"></span><span class="tag date"></span><span class="tag pri"></span><span class="tag rep"></span><span class="tag remind"></span></div></div><div class="actions"><button class="del">🗑</button></div>';
   c.querySelector(".title").textContent=x.title;c.querySelector(".type").textContent=x.type;c.querySelector(".date").textContent=fmt(x);
   if(x.priority!=="Normal"){c.querySelector(".pri").textContent=x.priority;c.querySelector(".pri").classList.add(x.priority==="Acil"?"urgent":"important")}else c.querySelector(".pri").remove();
   if(x.repeat)c.querySelector(".rep").textContent="↻ "+labelRepeat(x.repeat);else c.querySelector(".rep").remove();
   if(x.reminder_offset_minutes)c.querySelector(".remind").textContent=fmtReminder(x);else c.querySelector(".remind").remove();
   c.querySelector(".check").onclick=()=>toggle(x);c.querySelector(".del").onclick=()=>confirm("Bu kaydı silmek istiyor musun?")&&remove(x);list.appendChild(c)
 }
}

function openManual(prefill=null){
 $("fTitle").value=prefill?.title||"";$("fDate").value=prefill?.date||"";$("fTime").value=prefill?.time||"";$("fType").value=prefill?.type||"Görev";
 $("fPriority").value=prefill?.priority||"Normal";$("fReminder").value=String(prefill?.reminder_offset_minutes??0);$("fRepeat").value=prefill?.repeat||"";$("fNote").value=prefill?.note||"";
 $("modal").showModal();$("fTitle").focus();
}
function showInterpretation(obj){
 pending=obj;$("previewTitle").textContent=obj.title;$("previewType").value=obj.type;$("previewDate").value=obj.date;$("previewTime").value=obj.time;
 $("previewPriority").value=obj.priority;$("previewReminder").value=String(obj.reminder_offset_minutes??0);$("previewRepeat").value=obj.repeat;
 const parts=[fmt(obj),reminderLabel(obj.reminder_offset_minutes)];$("previewSummary").textContent=parts.filter(Boolean).join(" • ");
 $("previewWarnings").innerHTML="";
 if(obj.source==="ai")$("previewWarnings").innerHTML+='<span class="ok">✓ AI ile yorumlandı</span>';
 for(const w of obj.warnings||[])$("previewWarnings").innerHTML+='<span class="warn">⚠️ '+escapeHtml(w)+'</span>';
 if(!obj.warnings?.length&&obj.source!=="ai")$("previewWarnings").innerHTML+='<span class="ok">✓ Temel bilgiler bulundu</span>';
 $("preview").showModal()
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[m]))}

async function processSmart(text){
 let obj=await aiInterpret(text);if(!obj)obj=localInterpret(text);
 if(obj.needs_clarification){clarifyBase=obj; $("clarifyQuestion").textContent=obj.clarifying_question||"Bir bilgiyi netleştirelim";$("clarifyInput").value="";$("clarify").showModal();$("clarifyInput").focus();return}
 showInterpretation(obj)
}

$("addQuick").onclick=async()=>{const t=$("quickInput").value.trim();if(!t)return;$("quickInput").value="";await processSmart(t)};
$("quickInput").addEventListener("keydown",e=>{if(e.key==="Enter")$("addQuick").click()});
document.querySelectorAll(".chip").forEach(b=>b.onclick=()=>{$("quickInput").value=b.dataset.q;$("quickInput").focus()});
$("confirmSmart").onclick=async()=>{if(!pending)return;pending.title=$("previewTitle").textContent.trim();pending.type=$("previewType").value;pending.date=$("previewDate").value;pending.time=$("previewTime").value;pending.priority=$("previewPriority").value;pending.reminder_offset_minutes=Number($("previewReminder").value);pending.repeat=$("previewRepeat").value;pending.warnings=[];pending.needs_clarification=false;await upsert(pending);pending=null;$("preview").close()};
$("editSmart").onclick=()=>{const x=pending;$("preview").close();pending=null;openManual(x)};
$("cancelSmart").onclick=()=>{$("preview").close();pending=null};

$("answerClarify").onclick=async()=>{const a=$("clarifyInput").value.trim();if(!a)return;
 $("clarify").close();const combined=clarifyBase.raw+" — Kullanıcı ek bilgi: "+a;clarifyBase=null;await processSmart(combined)
};
$("clarifyInput").addEventListener("keydown",e=>{if(e.key==="Enter")$("answerClarify").click()});
$("cancelClarify").onclick=()=>{$("clarify").close();clarifyBase=null};

$("manualBtn").onclick=()=>openManual();$("cancelBtn").onclick=()=>$("modal").close();
$("saveBtn").onclick=async()=>{const title=$("fTitle").value.trim();if(!title)return alert("Başlık gerekli.");await upsert({id:uid(),title,date:$("fDate").value,time:$("fTime").value,type:$("fType").value,priority:$("fPriority").value,repeat:$("fRepeat").value,reminder_offset_minutes:Number($("fReminder").value),note:$("fNote").value,done:false,created_at:new Date().toISOString()});$("modal").close()};

$("settingsBtn").onclick=()=>{$("aiEnabledToggle").checked=localStorage.getItem("unutmam.ai.enabled.v6")!=="false";$("settings").showModal()};
$("closeSettings").onclick=()=>$("settings").close();
$("aiEnabledToggle").onchange=()=>{localStorage.setItem("unutmam.ai.enabled.v6",$("aiEnabledToggle").checked?"true":"false");updateAiNote()};
$("notifyBtn").onclick=async()=>{if(!("Notification"in window))return alert("Bildirim desteklenmiyor.");toast((await Notification.requestPermission())==="granted"?"Bildirim izni verildi.":"Bildirim izni verilmedi.")};
$("exportBtn").onclick=()=>{const b=new Blob([JSON.stringify(items,null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(b);a.download="unutmam-yedek-v6.json";a.click();URL.revokeObjectURL(a.href)};
$("clearLocalBtn").onclick=()=>{if(confirm("Bu cihazdaki yerel kayıtlar temizlensin mi?")){items=[];save();render();toast("Yerel kayıtlar temizlendi.")}};
$("clearDoneBtn").onclick=async()=>{const done=items.filter(x=>x.done);if(!done.length)return toast("Tamamlanan kayıt yok.");if(!confirm(done.length+" tamamlanan kayıt silinsin mi?"))return;for(const x of done){if(supabase&&session)await supabase.from("items").delete().eq("id",x.id)}items=items.filter(x=>!x.done);save();render();toast("Tamamlananlar temizlendi.")};
$("logoutBtn").onclick=async()=>{if(supabase)await supabase.auth.signOut();session=null;$("settings").close();await load();refreshAuth()};

$("loginOpen").onclick=()=>{if(!supabase)return alert("Bu paket yerel modda çalışıyor. Bulut için config.js içine Supabase bilgilerini ekle.");$("auth").showModal()};
$("authToggle").onclick=()=>{authMode=authMode==="login"?"signup":"login";$("authTitle").textContent=authMode==="login"?"Hesabına giriş yap":"Hesap oluştur";$("loginBtn").textContent=authMode==="login"?"Giriş yap":"Kayıt ol"};
$("loginBtn").onclick=async()=>{const email=$("authEmail").value.trim(),password=$("authPassword").value;if(!email||password.length<6)return alert("Geçerli e-posta ve en az 6 karakter parola gerekli.");let r;if(authMode==="login")r=await supabase.auth.signInWithPassword({email,password});else r=await supabase.auth.signUp({email,password});if(r.error)return alert(r.error.message);session=r.data.session||null;$("auth").close();await load();refreshAuth();toast(authMode==="login"?"Giriş yapıldı.":"Hesap oluşturuldu.")};

function updateAiNote(){
 const on=localStorage.getItem("unutmam.ai.enabled.v6")!=="false";
 $("aiNote").textContent=on&&cfg.AI_PARSER_ENABLED?"AI akıllı yorumlama açık. Cümlenin anlamını daha doğal çözmeye çalışır.":"Yerel yorumlama açık. Tarih/saat kuralları cihazda işlenir.";
}
function refreshAuth(){$("userLabel").textContent=session?session.user.email:"Yerel mod";$("loginOpen").textContent=session?"Hesap":"Giriş";updateAiNote()}
if(supabase){supabase.auth.getSession().then(async({data})=>{session=data.session;refreshAuth();await load()});supabase.auth.onAuthStateChange((_e,s)=>{session=s;refreshAuth();load()})}else{refreshAuth();render()}

// ---- V11/V12/V13/V15 product layer ----
let activeFilter="all", searchTerm="";
function installProductLayer(){
  const hero=document.querySelector(".hero");
  if(!hero || document.getElementById("productSearch"))return;
  const row=document.createElement("div"); row.style.cssText="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap";
  row.innerHTML=`<input id="productSearch" aria-label="Ara" placeholder="🔎 Kayıtlarında ara..." style="flex:1;min-width:180px;border:1px solid #e5e7eb;border-radius:11px;padding:9px;background:#fff;color:#111827">
  <select id="productFilter" style="border:1px solid #e5e7eb;border-radius:11px;padding:9px;background:#fff;color:#111827">
  <option value="all">Hepsi</option><option value="today">Bugün</option><option value="overdue">Geciken</option><option value="important">Önemli</option><option value="open">Açık</option><option value="done">Tamamlanan</option></select>`;
  hero.appendChild(row);
  const s=document.getElementById("productSearch"); const f=document.getElementById("productFilter");
  const rerender=()=>{searchTerm=s.value.toLocaleLowerCase("tr-TR").trim();activeFilter=f.value;renderProductFiltered()};
  s.addEventListener("input",rerender);f.addEventListener("change",rerender);
  renderProductFiltered();
}
function renderProductFiltered(){
  const list=document.getElementById("list"); if(!list)return;
  const t=today();
  let filtered=[...items];
  if(searchTerm)filtered=filtered.filter(x=>(`${x.title} ${x.note||""} ${x.type}`).toLocaleLowerCase("tr-TR").includes(searchTerm));
  if(activeFilter==="today")filtered=filtered.filter(x=>x.date===t&&!x.done);
  if(activeFilter==="overdue")filtered=filtered.filter(x=>x.date&&x.date<t&&!x.done);
  if(activeFilter==="important")filtered=filtered.filter(x=>x.priority!=="Normal"&&!x.done);
  if(activeFilter==="open")filtered=filtered.filter(x=>!x.done);
  if(activeFilter==="done")filtered=filtered.filter(x=>x.done);
  const original=items; items=filtered; render(); items=original;
}
if(isNative && session) registerNativePush();
setTimeout(installProductLayer,200);

const originalUpsert=upsert;
upsert=async(x)=>{
  x.timezone=x.timezone||Intl.DateTimeFormat().resolvedOptions().timeZone||"Europe/Istanbul";
  x.source=x.source||"manual";
  await originalUpsert(x);
  if(isNative && !session && x.date && x.time){ try{ await LocalNotifications.schedule({notifications:[{id:Math.abs(hashCode(x.id)),title:"Unutmam",body:x.title,schedule:{at:new Date(x.date+"T"+x.time)}}]}); }catch{} }
};
function hashCode(s){let h=0;for(let i=0;i<s.length;i++)h=((h<<5)-h)+s.charCodeAt(i)|0;return Math.abs(h)||1;}
