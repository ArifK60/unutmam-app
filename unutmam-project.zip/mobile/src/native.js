import { Capacitor } from "@capacitor/core";
import { App } from "@capacitor/app";
import { PushNotifications } from "@capacitor/push-notifications";
import { LocalNotifications } from "@capacitor/local-notifications";
import { supabase } from "./app.js";

async function registerPush(){
  if(Capacitor.getPlatform()==="web") return;
  const perm=await PushNotifications.checkPermissions();
  const granted=perm.receive==="granted"?perm:await PushNotifications.requestPermissions();
  if(granted.receive!=="granted") return;
  await PushNotifications.createChannel?.({id:"unutmam_reminders",name:"Unutmam Hatırlatıcıları",description:"Hatırlatıcı bildirimleri",importance:5,sound:"default",visibility:1});
  await PushNotifications.register();
  PushNotifications.addListener("registration",async token=>{
    if(!supabase) return;
    const {data:{session}}=await supabase.auth.getSession();
    if(!session) return;
    const platform=Capacitor.getPlatform();
    await supabase.from("device_tokens").upsert({user_id:session.user.id,endpoint:token.value,platform,token_type:"push",enabled:true,last_seen_at:new Date().toISOString(),app_version:"15.6.0"},{onConflict:"user_id,endpoint"});
  });
  PushNotifications.addListener("registrationError",err=>console.warn("Push registration failed",err));
  PushNotifications.addListener("pushNotificationActionPerformed",event=>{
    const id=event.notification?.data?.item_id;
    if(id) window.location.hash=`item/${id}`;
  });
}

async function initNative(){
  if(Capacitor.getPlatform()==="web") return;
  try{await LocalNotifications.requestPermissions();}catch{}
  await registerPush();
  App.addListener("appUrlOpen",({url})=>{try{const u=new URL(url);if(u.protocol==="unutmam:"&&u.hostname==="item"){window.location.hash=`item/${u.pathname.replace(/^\//,"")}`}}catch{}});
}

initNative().catch(err=>console.warn("Native init failed",err));
