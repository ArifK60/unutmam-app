-- Run only in a disposable/staging Supabase database.
-- Requires an authenticated test user UUID in :user_id.
insert into public.items (user_id,title,due_at,priority,done,timezone,source)
select :user_id::uuid,
       'Perf test '||g,
       now() + ((g % 1440) || ' minutes')::interval,
       case when g % 10 = 0 then 'high' when g % 3 = 0 then 'medium' else 'low' end,
       false,'Europe/Istanbul','perf-test'
from generate_series(1,10000) g;
