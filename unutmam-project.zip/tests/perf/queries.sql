-- Staging-only benchmark queries. Capture EXPLAIN (ANALYZE, BUFFERS).
select count(*) from public.items where user_id=:user_id and deleted_at is null;
select id,title,due_at,priority from public.items where user_id=:user_id and deleted_at is null order by due_at limit 100;
select id,title from public.items where user_id=:user_id and deleted_at is null and search_vector @@ websearch_to_tsquery('turkish','Perf test') limit 100;
