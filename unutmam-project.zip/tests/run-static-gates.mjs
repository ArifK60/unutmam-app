import fs from 'node:fs';
import { execFileSync } from 'node:child_process';
const root=new URL('..',import.meta.url).pathname;
const js=['frontend/app.js','mobile/src/main.js','mobile/src/native.js'];
for(const file of js){execFileSync(process.execPath,['--check',file],{cwd:root,stdio:'inherit'});}
const corpus=JSON.parse(fs.readFileSync(new URL('./stress-cases-tr.json',import.meta.url),'utf8'));
if(corpus.length<300) throw new Error('Turkish stress corpus must contain at least 300 cases');
for(const c of corpus){if(!c.input||!c.category)throw new Error(`Bad stress case ${c.id}`)}
const ai=fs.readFileSync(new URL('../supabase/functions/ai-parser/index.ts',import.meta.url),'utf8');
if(ai.includes('gpt-6-luna'))throw new Error('Stale AI model id found');
if(!ai.includes('gpt-5.6-luna'))throw new Error('Production AI model default missing');
const cal=fs.readFileSync('supabase/functions/calendar-google-callback/index.ts','utf8');
if((cal.match(/Deno\.serve\(/g)||[]).length!==1)throw new Error('Google callback must expose exactly one Deno.serve handler');
if(!cal.includes('CALENDAR_TOKEN_ENCRYPTION_KEY'))throw new Error('Calendar token encryption missing');
if(!cal.includes('GOOGLE_OAUTH_STATE_SECRET'))throw new Error('OAuth state signing missing');
const worker=fs.readFileSync(new URL('../supabase/functions/reminder-worker/index.ts',import.meta.url),'utf8');
for(const marker of ['claim_reminder_delivery','next_attempt_at','attempt_count'])if(!worker.includes(marker))throw new Error(`Worker hardening missing: ${marker}`);
const migration=fs.readFileSync(new URL('../supabase/migrations/006_production_hardening.sql',import.meta.url),'utf8');
for(const marker of ['deleted_at','claim_reminder_delivery','set_updated_at'])if(!migration.includes(marker))throw new Error(`Migration hardening missing: ${marker}`);
console.log(JSON.stringify({ok:true,js_checked:js.length,stress_cases:corpus.length,checks:['AI model','offline queue','soft delete','delivery lease/retry','updated_at trigger']},null,2));
