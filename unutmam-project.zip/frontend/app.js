import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cfg=window.UNUTMAM_CONFIG||{};
const cloudEnabled=/^https:\/\/.+\.supabase\.co(m)?$/.test(cfg.SUPABASE_URL||"")&&!!cfg.SUPABASE_PUBLISHABLE_KEY&&!cfg.SUPABASE_PUBLISHABLE_KEY.includes("YOUR_");
export const supabase=cloudEnabled?createClient(cfg.SUPABASE_URL,cfg.SUPABASE_PUBLISHABLE_KEY):null;

const KEY="unutmam.items.v6";
const QUEUE_KEY="unutmam.sync.queue.v15";
let items=JSON.parse(localStorage.getItem(KEY)||"[]"),syncQueueState=JSON.parse(localStorage.getItem(QUEUE_KEY)||"[]"),session=null,pending=null,clarifyBase=null,authMode="login";
const $=id=>document.getElementById(id);
const uid=()=>crypto.randomUUID?crypto.randomUUID():Date.now()+"-"+Math.random();
const nowDate=new Date();
const today=()=>{const d=new Date();return new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,10)};
const iso=d=>new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,10);
const months={ocak:0,şubat:1,mart:2,nisan:3,mayıs:4,haziran:5,temmuz:6,ağustos:7,eylül:8,ekim:9,kasım:10,aralık:11};
const allowedTypes=["Görev","Fatura","Abonelik","Randevu","Belge","Garanti","Bakım","Diğer"];
const allowedPriorities=["Normal","Önemli","Acil"];
const REMINDER_LABELS={0:"Zamanı gelince",15:"15 dk önce",60:"1 saat önce",1440:"1 gün önce",2880:"2 gün önce",10080:"1 hafta önce"};

function save(){localStorage.setItem(KEY,JSON.stringify(items))}
function saveQueue(){localStorage.setItem(QUEUE_KEY,JSON.stringify(syncQueueState))}
function queueMutation(m){syncQueueState=syncQueueState.filter(q=>q.id!==m.id);syncQueueState.push(m);saveQueue()}
function dropMutation(id){syncQueueState=syncQueueState.filter(q=>q.id!==id);saveQueue()}
function toast(msg){const el=$("toast");el.textContent=msg;el.hidden=false;clearTimeout(toast.t);toast.t=setTimeout(()=>el.hidden=true,2200)}
function normalizeDateValue(v){return /^\d{4}-\d{2}-\d{2}$/.test(v||"")?v:""}
function normalizeTimeValue(v){return /^\d{2}:\d{2}$/.test(v||"")?v:""}
function parseDate(t){
 t=t.toLocaleLowerCase("tr-TR");const now=new Date(),base=new Date(now.getFullYear(),now.getMonth(),now.getDate());
 if(/\bbugün\b/.test(t))return iso(base);
 if(/\byarın\b/.test(t)){const d=new Date(base);d.setDate(d.getDate()+1);return iso(d)}
 if(/\b(öbür gün|öbürgün)\b/.test(t)){const d=new Date(base);d.setDate(d.getDate()+2);return iso(d)}
 if(/\bbu hafta\b/.test(t)){const d=new Date(base),day=d.getDay()||7;d.setDate(d.getDate()+(day===1?0:8-day));return iso(d)}
 let m=t.match(/(\d+)\s*(gün|hafta|ay|yıl)\s*sonra/);
 if(m){const n=+m[1],d=new Date(base);if(m[2]==="gün")d.setDate(d.getDate()+n);if(m[2]==="hafta")d.setDate(d.getDate()+7*n);if(m[2]==="ay")d.setMonth(d.getMonth()+n);if(m[2]==="yıl")d.setFullYear(d.getFullYear()+n);return iso(d)}
 for(const [name,idx] of Object.entries(months)){m=t.match(new RegExp("(\\d{1,2})\\s*"+name+"(?:\\s*(\\d{4}))?"));if(m){const d=new Date(m[2]?+m[2]:now.getFullYear(),idx,+m[1]);if(!m[2]&&d<base)d.setFullYear(d.getFullYear()+1);return iso(d)}}
 m=t.match(/\b(\d{1,2})[./-](\d{1,2})(?:[./-](\d{4}))?\b/);
 if(m){const d=new Date(m[3]?+m[3]:now.getFullYear(),+m[2]-1,+m[1]);if(!m[3]&&d<base)d.setFullYear(d.getFullYear()+1);return iso(d)}
 return "";
}
function parseTime(t){
 let m=t.match(/\b([01]?\d|2[0-3])[:.](\d{2})\b/);if(m)return m[1].padStart(2,"0")+":"+m[2];
 m=t.match(/\b(saat|saatinde|de|da)\s*([01]?\d|2[0-3])\b/);if(m)return m[2].padStart(2,"0")+":00";
 return "";
}
function guessType(t){t=t.toLocaleLowerCase("tr-TR");if(/fatura|elektrik|su fatur|doğalgaz|internet fatur/.test(t))return"Fatura";if(/abonelik|üyelik|netflix|spotify/.test(t))return"Abonelik";if(/doktor|diş|randevu|hastane|muayene/.test(t))return"Randevu";if(/pasaport|ehliyet|kimlik|belge|ruhsat|vize/.test(t))return"Belge";if(/garanti|garantisi/.test(t))return"Garanti";if(/bakım|servis|yağ değiş|lastik|muayene/.test(t))return"Bakım";return"Görev"}
function guessRepeat(t){t=t.toLocaleLowerCase("tr-TR");if(/her gün|günlük/.test(t))return"daily";if(/her hafta|haftalık|haftada bir/.test(t))return"weekly";if(/her ay|aylık|ayda bir/.test(t))return"monthly";if(/her yıl|yıllık|yılda bir/.test(t))return"yearly";return""}
function guessPriority(t){t=t.toLocaleLowerCase("tr-TR");if(/acil|çok önemli|hemen/.test(t))return"Acil";if(/önemli|kritik/.test(t))return"Önemli";return"Normal"}
function cleanTitle(t){
 return t.replace(/\b(bugün|yarın|öbür gün|öbürgün|bu hafta)\b/ig,"")
 .replace(/\b\d+\s*(gün|hafta|ay|yıl)\s*sonra\b/ig,"")
 .replace(/\b\d{1,2}[./-]\d{1,2}(?:[./-]\d{4})?\b/g,"")
 .replace(/\b\d{1,2}\s*(ocak|şubat|mart|nisan|mayıs|haziran|temmuz|ağustos|eylül|ekim|kasım|aralık)(?:\s*\d{4})?\b/ig,"")
 .replace(/\b(saat|saatinde)\s*([01]?\d|2[0-3])(?::\d{2})?\b/ig,"")
 .replace(/\bher (gün|hafta|ay|yıl)\b/ig,"")
 .replace(/\s+/g," ").replace(/^[,.\s]+|[,.\s]+$/g,"").trim();
}
function localInterpret(text){
 const date=parseDate(text),time=parseTime(text),type=guessType(text),repeat=guessRepeat(text),priority=guessPriority(text),low=text.toLocaleLowerCase("tr-TR");
 const warnings=[];let needsClarification=false,clarifying_question="";
 if(!date && /hatırlat|unutma|randevu|toplantı|sınav|uçuş|fatura son|son gün/.test(low)){warnings.push("Tarih belirtilmemiş");needsClarification=true;clarifying_question="Hangi gün hatırlatayım?"}
 if(/randevu|doktor|diş|toplantı|uçak|uçuş|sınav/.test(low)&&!time){warnings.push("Saat belirtilmemiş");needsClarification=true;clarifying_question="Hangi saat için?"}
 return {id:uid(),raw:text,title:cleanTitle(text)||text,date,time,type,repeat,priority,note:"",done:false,created_at:new Date().toISOString(),reminder_offset_minutes:0,needs_clarification:needsClarification,clarifying_question,warnings,source:"local"};
}

async function aiEnabled(){
 return !!cfg.AI_PARSER_ENABLED && !!supabase && session && localStorage.getItem("unutmam.ai.enabled.v6")!=="false";
}
async function aiInterpret(text){
 const tz=Intl.DateTimeFormat().resolvedOptions().timeZone||"Europe/Istanbul";
 if(!await aiEnabled())return null;
 const btn=$("addQuick"),old=btn.textContent;btn.textContent="AI...";$("addQuick").disabled=true;
 try{
   const {data,error}=await supabase.functions.invoke("ai-parser",{body:{text,timezone:tz,locale:"tr-TR",now:new Date().toISOString()}});
   if(error)throw error;
   const d=data?.result;
   if(!d)throw new Error("AI cevabı boş");
   const out={
     id:uid(),raw:text,title:(d.title||text).trim(),date:normalizeDateValue(d.date),time:normalizeTimeValue(d.time),
     type:allowedTypes.includes(d.type)?d.type:"Görev",priority:allowedPriorities.includes(d.priority)?d.priority:"Normal",
     repeat:["","daily","weekly","monthly","yearly"].includes(d.repeat)?d.repeat:"",
     reminder_offset_minutes:[0,15,60,1440,2880,10080].includes(Number(d.reminder_offset_minutes))?Number(d.reminder_offset_minutes):0,
     note:d.note||"",done:false,created_at:new Date().toISOString(),
     needs_clarification:!!d.needs_clarification,clarifying_question:d.clarifying_question||"",warnings:Array.isArray(d.warnings)?d.warnings:[],source:"ai"
   };
   return out;
 }catch(e){
   console.warn("AI parser failed",e);
   toast("AI yorumlanamadı; yerel yorumlamaya geçtim.");
   return null;
 }finally{$("addQuick").disabled=false;btn.textContent=old}
}
function labelRepeat(r){return({daily:"Her gün",weekly:"Her hafta",monthly:"Her ay",yearly:"Her yıl"})[r]||"Yok"}
function reminderLabel(n){return REMINDER_LABELS[Number(n)]||"Zamanı gelince"}
function fmt(x){if(!x.date)return"Tarih yok";const d=new Date(x.date+"T00:00:00");return d.toLocaleDateString("tr-TR",{day:"numeric",month:"short",year:"numeric"})+(x.time?" • "+x.time:"")}
function fmtReminder(x){return x.date?"↳ "+reminderLabel(x.reminder_offset_minutes):""}
function localDateTimeToIso(date,time,timezone){
 if(!date)return null; const hhmm=time||"00:00";
 try{
   const [y,m,d]=date.split("-").map(Number),[hh,mm]=hhmm.split(":").map(Number);
   const guess=new Date(Date.UTC(y,m-1,d,hh,mm,0));
   const parts=new Intl.DateTimeFormat("en-US",{timeZone:timezone,timeZoneName:"longOffset",year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit",hourCycle:"h23"}).formatToParts(guess);
   const map=Object.fromEntries(parts.map(p=>[p.type,p.value])); const off=(map.timeZoneName||"GMT").replace("GMT","")||"+00:00";
   return `${date}T${hhmm}:00${off.length===6?off:off.replace(/^([+-])(\d)(:)/,'$10$2$3')}`;
 }catch{return `${date}T${hhmm}:00+03:00`}
}
function zoneParts(isoValue,timezone){
 if(!isoValue)return {date:"",time:""};
 try{const p=new Intl.DateTimeFormat("en-CA",{timeZone:timezone||"Europe/Istanbul",year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",hourCycle:"h23"}).formatToParts(new Date(isoValue));const m=Object.fromEntries(p.map(x=>[x.type,x.value]));return {date:`${m.year}-${m.month}-${m.day}`,time:`${m.hour}:${m.minute}`};}catch{return {date:isoValue.slice(0,10),time:isoValue.slice(11,16)}}
}
function dbRow(x){const timezone=x.timezone||Intl.DateTimeFormat().resolvedOptions().timeZone||"Europe/Istanbul";return{id:x.id,user_id:session.user.id,title:x.title,note:x.note||null,item_type:x.type,priority:x.priority,due_at:localDateTimeToIso(x.date,x.time,timezone),repeat_rule:x.repeat||null,repeat_rule_json:x.repeat_rule_json||null,timezone,done:!!x.done,reminder_offset_minutes:Number(x.reminder_offset_minutes)||0,updated_at:x.updated_at||new Date().toISOString(),deleted_at:x.deleted_at||null,source:x.source||"manual"}}
function apiRow(x){const timezone=x.timezone||"Europe/Istanbul",parts=zoneParts(x.due_at,timezone);return{id:x.id,title:x.title,note:x.note||"",type:x.item_type,priority:x.priority,date:parts.date,time:parts.time,repeat:x.repeat_rule||"",reminder_offset_minutes:Number(x.reminder_offset_minutes)||0,done:x.done,created_at:x.created_at,updated_at:x.updated_at,timezone,source:x.source||"cloud"}}
function overlayQueued(serverItems){let map=new Map(serverItems.map(x=>[x.id,x]));for(const q of syncQueueState){if(q.op==="delete")map.delete(q.id);else if(q.op==="upsert")map.set(q.id,q.row)}return [...map.values()]}
async function syncQueue(){if(!supabase||!session||!navigator.onLine||!syncQueueState.length)return;const queue=[...syncQueueState];for(const q of queue){try{if(q.op==="upsert"){const {data:server}=await supabase.from("items").select("*").eq("id",q.id).maybeSingle();const localTime=new Date(q.row.updated_at||0).getTime(),serverTime=new Date(server?.updated_at||0).getTime();if(server&&serverTime>localTime){items=items.map(i=>i.id===q.id?apiRow(server):i);dropMutation(q.id);continue}const {error}=await supabase.from("items").upsert(dbRow(q.row));if(error)continue;dropMutation(q.id)}else if(q.op==="delete"){const stamp=q.deleted_at||new Date().toISOString();const {error}=await supabase.from("items").update({deleted_at:stamp,updated_at:stamp}).eq("id",q.id).eq("user_id",session.user.id);if(error)continue;dropMutation(q.id)}}catch(e){console.warn("sync failed",e)}}save();render();}
async function load(){
 if(!supabase){render();return}
 const {data,error}=await supabase.from("items").select("*").is("deleted_at",null).order("due_at",{ascending:true,nullsFirst:false});
 if(error){console.error(error);toast(navigator.onLine?"Bulut kayıtları alınamadı.":"Çevrimdışısın; yerel kayıtların gösteriliyor.");render();return}
 items=overlayQueued((data||[]).map(apiRow));save();await syncQueue();render()
}
async function upsert(x){
 const clean={...x};delete clean.warnings;delete clean.raw;delete clean.needs_clarification;delete clean.clarifying_question;
 clean.updated_at=new Date().toISOString();clean.timezone=clean.timezone||Intl.DateTimeFormat().resolvedOptions().timeZone||"Europe/Istanbul";clean.source=clean.source||"manual";
 items=items.filter(i=>i.id!==clean.id);items.unshift(clean);save();render();
 if(!supabase||!session){toast("Kaydedildi.");return}
 if(!navigator.onLine){queueMutation({op:"upsert",id:clean.id,row:clean});toast("İnternet yok. Cihazda kaydettim; bağlantı gelince eşitleyeceğim.");return}
 const {error}=await supabase.from("items").upsert(dbRow(clean));
 if(error){queueMutation({op:"upsert",id:clean.id,row:clean});toast("Bağlantı sorunu. Cihazda kaydettim; sonra eşitleyeceğim.");return}
 dropMutation(clean.id);await load();toast("Kaydedildi.")
}
async function remove(x){
 const stamp=new Date().toISOString();items=items.filter(i=>i.id!==x.id);save();render();
 if(supabase&&session){queueMutation({op:"delete",id:x.id,deleted_at:stamp});if(navigator.onLine)await syncQueue()}
 toast("Silindi.")
}
function nextDate(x){
 if(!x.repeat||!x.date)return x.date;const d=new Date(x.date+"T00:00:00");
 if(x.repeat==="daily")d.setDate(d.getDate()+1);if(x.repeat==="weekly")d.setDate(d.getDate()+7);
 if(x.repeat==="monthly")d.setMonth(d.getMonth()+1);if(x.repeat==="yearly")d.setFullYear(d.getFullYear()+1);return iso(d)
}
async function toggle(x){if(x.repeat&&!x.done)x.date=nextDate(x);else x.done=!x.done;await upsert(x)}
function render(){
 const t=today(),active=items.filter(x=>!x.done);$("todayCount").textContent=active.filter(x=>x.date===t).length;$("overdueCount").textContent=active.filter(x=>x.date&&x.date<t).length;$("allCount").textContent=items.length;
 const sorted=[...items].sort((a,b)=>(a.done?1:0)-(b.done?1:0)||(a.date||"9999").localeCompare(b.date||"9999"));const list=$("list");list.innerHTML="";
 if(!sorted.length){list.innerHTML='<div class="empty">Henüz kayıt yok.<br>Yukarıdan aklına geleni yaz.</div>';return}
 for(const x of sorted.slice(0,100)){
   const c=document.createElement("div");c.className="card "+(x.done?"done":"");
   c.innerHTML='<button class="check">'+(x.done?"✓":"")+'</button><div class="body"><div class="title"></div><div class="meta"><span class="tag type"></span><span class="tag date"></span><span class="tag pri"></span><span class="tag rep"></span><span class="tag remind"></span></div></div><div class="actions"><button class="del">🗑</button></div>';
   c.querySelector(".title").textContent=x.title;c.querySelector(".type").textContent=x.type;c.querySelector(".date").textContent=fmt(x);
   if(x.priority!=="Normal"){c.querySelector(".pri").textContent=x.priority;c.querySelector(".pri").classList.add(x.priority==="Acil"?"urgent":"important")}else c.querySelector(".pri").remove();
   if(x.repeat)c.querySelector(".rep").textContent="↻ "+labelRepeat(x.repeat);else c.querySelector(".rep").remove();
   if(x.reminder_offset_minutes)c.querySelector(".remind").textContent=fmtReminder(x);else c.querySelector(".remind").remove();
   c.querySelector(".check").onclick=()=>toggle(x);c.querySelector(".del").onclick=()=>confirm("Bu kaydı silmek istiyor musun?")&&remove(x);list.appendChild(c)
 }
}

function openManual(prefill=null){
 $("fTitle").value=prefill?.title||"";$("fDate").value=prefill?.date||"";$("fTime").value=prefill?.time||"";$("fType").value=prefill?.type||"Görev";
 $("fPriority").value=prefill?.priority||"Normal";$("fReminder").value=String(prefill?.reminder_offset_minutes??0);$("fRepeat").value=prefill?.repeat||"";$("fNote").value=prefill?.note||"";
 $("modal").showModal();$("fTitle").focus();
}
function showInterpretation(obj){
 pending=obj;$("previewTitle").textContent=obj.title;$("previewType").value=obj.type;$("previewDate").value=obj.date;$("previewTime").value=obj.time;
 $("previewPriority").value=obj.priority;$("previewReminder").value=String(obj.reminder_offset_minutes??0);$("previewRepeat").value=obj.repeat;
 const parts=[fmt(obj),reminderLabel(obj.reminder_offset_minutes)];$("previewSummary").textContent=parts.filter(Boolean).join(" • ");
 $("previewWarnings").innerHTML="";
 if(obj.source==="ai")$("previewWarnings").innerHTML+='<span class="ok">✓ AI ile yorumlandı</span>';
 for(const w of obj.warnings||[])$("previewWarnings").innerHTML+='<span class="warn">⚠️ '+escapeHtml(w)+'</span>';
 if(!obj.warnings?.length&&obj.source!=="ai")$("previewWarnings").innerHTML+='<span class="ok">✓ Temel bilgiler bulundu</span>';
 $("preview").showModal()
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[m]))}

async function processSmart(text){
 let obj=await aiInterpret(text);if(!obj)obj=localInterpret(text);
 if(obj.needs_clarification){clarifyBase=obj; $("clarifyQuestion").textContent=obj.clarifying_question||"Bir bilgiyi netleştirelim";$("clarifyInput").value="";$("clarify").showModal();$("clarifyInput").focus();return}
 showInterpretation(obj)
}

$("addQuick").onclick=async()=>{const t=$("quickInput").value.trim();if(!t)return;$("quickInput").value="";await processSmart(t)};
$("quickInput").addEventListener("keydown",e=>{if(e.key==="Enter")$("addQuick").click()});
document.querySelectorAll(".chip").forEach(b=>b.onclick=()=>{$("quickInput").value=b.dataset.q;$("quickInput").focus()});
$("confirmSmart").onclick=async()=>{if(!pending)return;pending.title=$("previewTitle").textContent.trim();pending.type=$("previewType").value;pending.date=$("previewDate").value;pending.time=$("previewTime").value;pending.priority=$("previewPriority").value;pending.reminder_offset_minutes=Number($("previewReminder").value);pending.repeat=$("previewRepeat").value;pending.warnings=[];pending.needs_clarification=false;await upsert(pending);pending=null;$("preview").close()};
$("editSmart").onclick=()=>{const x=pending;$("preview").close();pending=null;openManual(x)};
$("cancelSmart").onclick=()=>{$("preview").close();pending=null};

$("answerClarify").onclick=async()=>{const a=$("clarifyInput").value.trim();if(!a)return;
 $("clarify").close();const combined=clarifyBase.raw+" — Kullanıcı ek bilgi: "+a;clarifyBase=null;await processSmart(combined)
};
$("clarifyInput").addEventListener("keydown",e=>{if(e.key==="Enter")$("answerClarify").click()});
$("cancelClarify").onclick=()=>{$("clarify").close();clarifyBase=null};

$("manualBtn").onclick=()=>openManual();$("cancelBtn").onclick=()=>$("modal").close();
$("saveBtn").onclick=async()=>{const title=$("fTitle").value.trim();if(!title)return alert("Başlık gerekli.");await upsert({id:uid(),title,date:$("fDate").value,time:$("fTime").value,type:$("fType").value,priority:$("fPriority").value,repeat:$("fRepeat").value,reminder_offset_minutes:Number($("fReminder").value),note:$("fNote").value,done:false,created_at:new Date().toISOString()});$("modal").close()};

$("settingsBtn").onclick=()=>{$("aiEnabledToggle").checked=localStorage.getItem("unutmam.ai.enabled.v6")!=="false";$("settings").showModal()};
$("closeSettings").onclick=()=>$("settings").close();
$("aiEnabledToggle").onchange=()=>{localStorage.setItem("unutmam.ai.enabled.v6",$("aiEnabledToggle").checked?"true":"false");updateAiNote()};
$("notifyBtn").onclick=async()=>{if(!("Notification"in window))return alert("Bildirim desteklenmiyor.");toast((await Notification.requestPermission())==="granted"?"Bildirim izni verildi.":"Bildirim izni verilmedi.")};
$("exportBtn").onclick=()=>{const b=new Blob([JSON.stringify(items,null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(b);a.download="unutmam-yedek-v6.json";a.click();URL.revokeObjectURL(a.href)};
$("clearLocalBtn").onclick=()=>{if(confirm("Bu cihazdaki yerel kayıtlar temizlensin mi?")){items=[];save();render();toast("Yerel kayıtlar temizlendi.")}};
$("clearDoneBtn").onclick=async()=>{const done=items.filter(x=>x.done);if(!done.length)return toast("Tamamlanan kayıt yok.");if(!confirm(done.length+" tamamlanan kayıt silinsin mi?"))return;for(const x of done)await remove(x);toast("Tamamlananlar temizlendi.")};
$("logoutBtn").onclick=async()=>{if(supabase)await supabase.auth.signOut();session=null;$("settings").close();await load();refreshAuth()};

$("loginOpen").onclick=()=>{if(!supabase)return alert("Bu paket yerel modda çalışıyor. Bulut için config.js içine Supabase bilgilerini ekle.");$("auth").showModal()};
$("authToggle").onclick=()=>{authMode=authMode==="login"?"signup":"login";$("authTitle").textContent=authMode==="login"?"Hesabına giriş yap":"Hesap oluştur";$("loginBtn").textContent=authMode==="login"?"Giriş yap":"Kayıt ol"};
$("loginBtn").onclick=async()=>{const email=$("authEmail").value.trim(),password=$("authPassword").value;if(!email||password.length<6)return alert("Geçerli e-posta ve en az 6 karakter parola gerekli.");let r;if(authMode==="login")r=await supabase.auth.signInWithPassword({email,password});else r=await supabase.auth.signUp({email,password});if(r.error)return alert(r.error.message);session=r.data.session||null;$("auth").close();await load();refreshAuth();toast(authMode==="login"?"Giriş yapıldı.":"Hesap oluşturuldu.")};
$("resetBtn").onclick=async()=>{if(!supabase)return alert("Şifre sıfırlama bulut modunda kullanılabilir.");const email=$("authEmail").value.trim();if(!email)return alert("Önce e-posta adresini yaz.");const r=await supabase.auth.resetPasswordForEmail(email,{redirectTo:location.origin});if(r.error)return alert(r.error.message);$("auth").close();toast("Şifre sıfırlama bağlantısı gönderildi.")};
$("deleteAccountBtn").onclick=async()=>{if(!session||!supabase)return alert("Önce hesabına giriş yapmalısın.");if(!confirm("Hesabını ve buluttaki verilerini silme talebi oluşturulsun mu? Bu işlem geri alınamaz."))return;const {data,error}=await supabase.functions.invoke("account-delete",{body:{confirm:true}});if(error||!data?.ok)return alert(error?.message||data?.error||"Silme talebi oluşturulamadı.");await supabase.auth.signOut();session=null;items=[];save();syncQueueState=[];saveQueue();$("settings").close();refreshAuth();render();toast("Hesap silme talebin alındı.")};

function updateAiNote(){
 const on=localStorage.getItem("unutmam.ai.enabled.v6")!=="false";
 $("aiNote").textContent=on&&cfg.AI_PARSER_ENABLED?"AI akıllı yorumlama açık. Cümlenin anlamını daha doğal çözmeye çalışır.":"Yerel yorumlama açık. Tarih/saat kuralları cihazda işlenir.";
}
function refreshAuth(){$("userLabel").textContent=session?session.user.email:"Yerel mod";$("loginOpen").textContent=session?"Hesap":"Giriş";updateAiNote()}
if(supabase){supabase.auth.getSession().then(async({data})=>{session=data.session;refreshAuth();await load()});supabase.auth.onAuthStateChange((_e,s)=>{session=s;refreshAuth();load()})}else{refreshAuth();render()}

// V10 web voice fallback: Web Speech API, with server transcription available to native builds.
(function(){
 const btn=document.getElementById("voiceBtn"); if(!btn)return;
 const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!SR){btn.textContent="🎙️ Sesle ekle (tarayıcı desteklemiyor)";return}
 let rec=null;
 btn.onclick=async()=>{
   if(rec){rec.stop();return}
   rec=new SR(); rec.lang="tr-TR"; rec.interimResults=false; rec.maxAlternatives=1;
   btn.textContent="⏺ Dinliyorum...";
   rec.onresult=e=>{document.getElementById("quickInput").value=e.results[0][0].transcript;document.getElementById("addQuick").click()};
   rec.onerror=()=>{toast("Ses algılanamadı.")};
   rec.onend=()=>{rec=null;btn.textContent="🎙️ Sesle ekle"};
   rec.start();
 };
})();

window.addEventListener("online",()=>{toast("İnternet geldi. Kayıtları eşitliyorum...");syncQueue()});
window.addEventListener("offline",()=>toast("Çevrimdışı mod: yeni kayıtlar cihazda tutulacak."));
